function xml_loadStr(xmlstr){
	 var mobjXmlDom = new ActiveXObject("microsoft.xmldom");
		mobjXmlDom.async = false;
		if( !mobjXmlDom.loadXML(xmlstr) )	{			
			return null;			
		}
		return mobjXmlDom;
}


function xml_loadXML(xmlUrl){
	 var mobjXmlDom = new ActiveXObject("microsoft.xmldom");
		mobjXmlDom.async = false;
		if( !mobjXmlDom.load(xmlUrl) ){
			return null;			
		}		
		return mobjXmlDom;
}

function xml_getFirstNode(node1,name){
  if (node1 == null) return null;
   var childNodes = node1.childNodes;
   for(var i=0 ;i<childNodes.length;i++){
      if(childNodes[i].nodeName==name){
	   	   return childNodes[i];
	  }
   }
   return null;
}

function xml_firstChildNodeCode(node1,code){
  if (node1 == null) return null;
   var childNodes = node1.childNodes;
   for(var i=0 ;i<childNodes.length;i++){
      if(childNodes[i].getAttribute("code")==code){
	   return childNodes[i];
	  }
   }
   return null;
}

function xml_elementValue(node2){
	if(node2==null) return null;
	var textnode = node2.firstChild;
	if(textnode==null) return "";
	return textnode.nodeValue;
}

function xml_childValue(node1,name){
  var node2 = xml_getFirstNode(node1,name);
  return xml_elementValue(node2);
}

function createFormNode(xmlDoc,form1){
   var formNode = xmlDoc.createElement("form");
   formNode.setAttribute("name",form1.name);
   xmlDoc.documentElement.appendChild(formNode);
   var elements = form1.elements;
   for(var i=0;i<elements.length;i++){
	  if( elements[i].disabled || elements[i].type == 'button' || elements[i].type == 'reset'){
		continue;  
	  }
	  if( (elements[i].type=="checkbox" || elements[i].type == "radio") && !elements[i].checked ){
		  continue;
	  }
      var paramnode = xmlDoc.createElement("param");
	  paramnode.setAttribute("name",elements[i].name);
	  paramnode.text = xml_getElementValue( elements[i] );
	  formNode.appendChild(paramnode);
   }
}

function createDom(){
  var xmlDoc=new ActiveXObject("MSXML2.DOMDocument");
  var newNode = xmlDoc.createElement("root");
  xmlDoc.appendChild(newNode);
  return xmlDoc;
}

function postDom(xmlDoc,urlstr){ 
  var xh =new ActiveXObject( "MSXML2.XMLHTTP")
  xh.open("POST",urlstr,false)
  xh.setRequestHeader("Content-Type","text/xml")
  xh.setRequestHeader("Content-Type","UTF-8")
  xh.send(xmlDoc);
  return xh.responseText;
}

function postForm(form1){
  var xmldom = createDom();
  createFormNode(xmldom,form1);
  return postDom(xmldom,form1.action);
}

function xml_getElementValue(ele){
	if(ele.type != 'select-one'){
		return ele.value;
	}else{
		var opsArr = ele.options;
		for(var i=0;i<opsArr.length;i++){
			if(opsArr[i].selected == true){
				return opsArr[i].value;
			}
		}
		return null;
	}
}

function createXmlHttp(){   
	var xmlhttp,alerted;    
	try {
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP")
	} catch (E) {
		alert("You must have Microsofts XML parsers available")
	}    
	if (!xmlhttp && !alerted) {
		try {
			xmlhttp = new XMLHttpRequest();
		} catch (e) {
			alert("You need a browser which supports an XMLHttpRequest Object.\nMozilla build 0.9.5 has this Object and IE5 and above!")
		}
	} 
	return xmlhttp;
}
