// ** I18N
Calendar._DN = new Array
("日",
 "一",
 "二",
 "三",
 "四",
 "五",
 "六",
 "日");
Calendar._MN = new Array
("1月",
 "2月",
 "3月",
 "4月",
 "5月",
 "6月",
 "7月",
 "8月",
 "9月",
 "10月",
 "11月",
 "12月");

// tooltips
Calendar._TT = {};
Calendar._TT["TOGGLE"] = "Toggle first day of week";
Calendar._TT["PREV_YEAR"] = "上一年";
Calendar._TT["PREV_MONTH"] = "上一月";
Calendar._TT["GO_TODAY"] = "返回当天";
Calendar._TT["NEXT_MONTH"] = "下一月";
Calendar._TT["NEXT_YEAR"] = "下一年";
Calendar._TT["SEL_DATE"] = "选择日期";
Calendar._TT["DRAG_TO_MOVE"] = "移动";
Calendar._TT["PART_TODAY"] = " (今天)";
Calendar._TT["MON_FIRST"] = "首先显示周一";
Calendar._TT["SUN_FIRST"] = "首先显示周日";
Calendar._TT["CLOSE"] = "关闭";
Calendar._TT["TODAY"] = "当天";
