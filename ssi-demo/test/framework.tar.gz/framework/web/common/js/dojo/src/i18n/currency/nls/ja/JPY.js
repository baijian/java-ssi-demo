({
	displayName: "日本円",
	symbol: "￥"
})