({
	displayName: "Euro"
})