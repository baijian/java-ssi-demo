({
	displayName: "Italian Lira"
})