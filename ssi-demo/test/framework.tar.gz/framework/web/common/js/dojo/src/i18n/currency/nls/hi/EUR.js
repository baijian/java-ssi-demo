({
	displayName: "युरो"
})