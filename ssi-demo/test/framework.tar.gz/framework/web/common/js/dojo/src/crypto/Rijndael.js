dojo.provide("dojo.crypto.Rijndael");
dojo.require("dojo.crypto");
dojo.require("dojo.experimental");

dojo.experimental("dojo.crypto.Rijndael");

dojo.crypto.Rijndael = new function(){
	this.encrypt=function(plaintext, key){
	};
	this.decrypt=function(ciphertext, key){
	};
}();
