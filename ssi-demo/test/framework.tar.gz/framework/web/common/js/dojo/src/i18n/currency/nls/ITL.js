({
	displayName: "ITL",
	symbol: "\u20A4"
})