dojo.provide("dojo.widget.ShowAction");
dojo.require("dojo.widget.*");

dojo.widget.defineWidget(
	"dojo.widget.ShowAction",
	dojo.widget.HtmlWidget,
{
	on: "",
	action: "",
	duration: 0,
	from: "",
	to: "",
	auto: "false"
});
