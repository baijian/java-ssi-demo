({
	displayName: "Japanese Yen"
})