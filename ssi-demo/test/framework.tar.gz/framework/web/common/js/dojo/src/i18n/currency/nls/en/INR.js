({
	displayName: "Indian Rupee"
})