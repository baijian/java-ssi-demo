({
	displayName: "米ドル"
})