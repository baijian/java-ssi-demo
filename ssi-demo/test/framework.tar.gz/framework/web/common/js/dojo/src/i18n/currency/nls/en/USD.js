({
	displayName: "US Dollar",
	symbol: "US$"
})