({
	displayName: "USD",
	symbol: "$"
})