({
	displayName: "अमरीकी डालर"
})