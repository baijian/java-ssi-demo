dojo.kwCompoundRequire({
	common: ["dojo.storage"],
	browser: ["dojo.storage.browser"],
	dashboard: ["dojo.storage.dashboard"]
});
dojo.provide("dojo.storage.*");

