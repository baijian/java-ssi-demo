({
	displayName: "British Pound Sterling"
})