// By default... don't pull in anything?  (todo: figure out what should be in list)
dojo.provide("dojo.graphics.*");
