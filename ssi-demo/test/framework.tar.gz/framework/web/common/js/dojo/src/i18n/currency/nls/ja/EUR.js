({
	displayName: "ユーロ"
})