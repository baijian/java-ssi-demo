({
	displayName: "インド ルピー",
	symbol: "INR"
})