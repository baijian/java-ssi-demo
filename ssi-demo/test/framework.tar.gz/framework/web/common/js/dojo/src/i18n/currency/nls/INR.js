({
	displayName: "INR",
	symbol: function(value){return (value == 1) ? "Re." : "Rs.";}
})