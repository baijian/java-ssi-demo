({
	symbol: "$"
})