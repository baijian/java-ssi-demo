({
	displayName: "イタリア リラ"
})