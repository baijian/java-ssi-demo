({
	'months-format-wide': ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"],
	'months-format-abbr': ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"],
	'months-standAlone-narrow': ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"],
	'days-format-wide': ["1", "2", "3", "4", "5", "6", "7"],
	'days-format-abbr': ["1", "2", "3", "4", "5", "6", "7"],
	'days-standAlone-narrow': ["1", "2", "3", "4", "5", "6", "7"],


	'dateFormat-full': "EEEE, yyyy MMMM dd",
	'dateFormat-long': "yyyy MMMM d",
	'dateFormat-medium': "yyyy MMM d",
	'dateFormat-short': "yy/MM/dd",

	'timeFormat-full': "HH:mm:ss z",
	'timeFormat-long': "HH:mm:ss z",
	'timeFormat-medium': "HH:mm:ss",
	'timeFormat-short': "HH:mm",

	am: 'AM',
	pm: 'PM',
	eras: ['BCE','CE']
})