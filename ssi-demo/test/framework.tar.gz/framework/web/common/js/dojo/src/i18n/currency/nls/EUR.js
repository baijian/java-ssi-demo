({
	displayName: "EUR",
	symbol: "\u20AC"
})