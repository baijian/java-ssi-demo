dojo.require("dojo.xml.Parse");
dojo.kwCompoundRequire({
	common:		["dojo.dom"],
    browser: 	["dojo.html.*"],
    dashboard: 	["dojo.html.*"],
    svg: 		["dojo.xml.svgUtil"]
});
dojo.provide("dojo.xml.*");
