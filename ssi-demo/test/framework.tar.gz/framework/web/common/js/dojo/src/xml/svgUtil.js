dojo.provide("dojo.xml.svgUtil");
// FIXME: add imports for deps!

dojo.xml.svgUtil = new function(){

	this.getInnerWidth = function(node){
		// FIXME: need to find out from dylan how to 
	}

	this.getOuterWidth = function(node){
		
	}

	this.getInnerHeight = function(node){
		
	}

	this.getOuterHeight = function(node){
		
	}

}
