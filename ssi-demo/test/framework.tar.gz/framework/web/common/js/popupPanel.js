
dojo.provide("dojo.widget.PopupPanel");

dojo.require("dojo.dnd.HtmlDragMove");
dojo.require("dojo.dnd.HtmlDragMoveSource");

var PopupPanel = Class.create();

PopupPanel.prototype ={
  initialize:function( url , title ,width){
    this.url=url;
    this.title= title;
    this.buildSkeleton( url ,title,width );
   
  },
  
  buildSkeleton:function( url , title ,width){
	 	   	                  
	    var xmlHttp=createXMLHttpRequest();
	        
	    var newUrl = url.split("/");
	    //使用　xmlHttpRequest 对象得到弹出框的骨架 
	    xmlHttp.open("post","/"+newUrl[1]+"/common/js/popup_panel.jsp",true); 
	    xmlHttp.onreadystatechange=function (){
	          if(xmlHttp.readyState==4){	                                                
	              var nodeDom ;
	              var ifm;
	               
	               if( document.getElementById('popup_panel')==null ||document.getElementById('popup_panel')=='undefined' ){	              
	                 nodeDom =  document.createElement("div") ;
	                 nodeDom.id = "popup_panel";
	                 if(width) nodeDom.style.width="800";
	                 else
	                  nodeDom.style.width="600";
	                 
	                 document.body.appendChild( nodeDom );
	                 //加一个背景iframe
	                 ifm = document.createElement("<iframe  style='position: absolute; left: 0px; top: 0px; width: 100%; height: 100%;z-index: -1; filter:Alpha(Opacity=\"0\");'>");
	                	
	                 ifm.id= "bgifm";	                	                 
	                 nodeDom.appendChild(ifm);
	                 	                 	              
	                 //定位
	                 nodeDom.style.position = "absolute";
                     var offsets = Position.cumulativeOffset( nodeDom );
		             		     		                    
	                 var parent = Position.offsetParent( nodeDom );
	                	                
	                 nodeDom.style.top = ( (parent.offsetHeight)/6 )+"px";
	                
	                 nodeDom.style.left = ( (parent.offsetWidth - nodeDom.offsetWidth)/2 )+"px";
	                 
	                 //加入innerHTML
	                 var innerDiv = document.createElement("div");
	                 innerDiv.id="div1";
	                 nodeDom.appendChild(innerDiv);
	                 
	               		         		         
	               		         		         
	               } else{    
	                      
	                 nodeDom = document.getElementById('popup_panel');
	                  Element.show(nodeDom);
	                  
	                  if( document.getElementById('control_panel')!=null )
	                       Element.hide( document.getElementById('control_panel') );
	                  
            
	               }
	                             
              
	                var innerDiv = (document.getElementById("div1"));
	               
	                innerDiv.innerHTML=xmlHttp.responseText;	
	                            		           		              	     
		            var tBtn = document.getElementById("toggleBtn");
		            
		            tBtn.onclick=function (){	
		                 	             		   	               
				      
				      Element.toggle( document.getElementById('popup_panel'));  
				      
				      var xmlHttp2=createXMLHttpRequest();
	                   
					    var newUrl2 = url.split("/");
					    
					    //使用　xmlHttpRequest 对象得到弹出框的骨架 
					    xmlHttp2.open("post","/"+newUrl2[1]+"/common/js/control_bar.jsp",true); 
					    xmlHttp2.onreadystatechange=function (){
					    if(xmlHttp2.readyState==4){  
					       var controlNode ;
	                          
	                
	                    if( document.getElementById('control_panel')==null ||document.getElementById('control_panel')=='undefined' ){	              
					         controlNode =  document.createElement("div") ;
			                 controlNode.id = "control_panel";			                 
			                 document.body.appendChild( controlNode );
			                 
			                 controlNode.innerHTML = xmlHttp2.responseText;
			                
			                 
			                 controlNode.style.position = "absolute";
		                     		     		                    
			                 var crlBarParent = Position.offsetParent( controlNode );			                	                
			                 controlNode.style.top = ( (crlBarParent.offsetTop))+"px";
			                 controlNode.style.left = ( (crlBarParent.offsetWidth - controlNode.offsetWidth) )+"px";
					    }else{
					        controlNode = document.getElementById('control_panel');
					        Element.show(controlNode);
					    }
				      
				       		     	      
				    
			           
			        var showBtn = document.getElementById("showBtn");
					 showBtn.onclick=function(){
						     Element.toggle( nodeDom );
						     Element.toggle(document.getElementById('control_panel'));
					 };
			 
			     var cBtn1 = document.getElementById("closeBtn1");
	      
			      cBtn1.onclick = function (){
			           Element.hide( document.getElementById('control_panel') );
			          
			      };
	              			          					 	        
				}};
				
				  xmlHttp2.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	              xmlHttp2.send( null ); 
			 
			};	 
				  

	 
	    var cBtn = document.getElementById("closeBtn");
	    	   
	     cBtn.onclick = function (){
	         Element.hide(nodeDom);
	      
	      };
	        
	    var titleBar = document.getElementById("title_bar");    
	    
	    titleBar.innerHTML = title;
	      	    
	      	    	      	    
	    var xmlHttp1=createXMLHttpRequest();	  
	    xmlHttp1.open("post",url,true); 
	    xmlHttp1.onreadystatechange=function (){
	          if(xmlHttp1.readyState==4){          
	              var container = document.getElementById("nodeContainer");   
	             
	                Element.update(container, xmlHttp1.responseText);
	                //
	                var midNode = document.getElementById("popup_panel");
	                
	                with(  (document.getElementById("bgifm")).style){
	                    width=midNode.offsetWidth;
	                    height= midNode.offsetHeight;
	                }	              
				
					                	 
	              //设置可拖动
	                var drag = new dojo.dnd.HtmlDragMoveSource(document.getElementById('popup_panel'));	
				
			        drag.constrainTo();
				
			        drag.setDragHandle("popup_panel"); 
			                      
	          }};
	    	             
			    xmlHttp1.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
			    xmlHttp1.send( null );    
			  
	        }    
	     };
	    xmlHttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	    xmlHttp.send( null );  
	   
    	                                   
  },
  
  remove:function (){
      Element.hide( document.getElementById("popup_panel") ); 
  }
  
 
}


//create a xmlHttp object
function createXMLHttpRequest(){
   var xmlHttp;
      if(window.ActiveXObject ){
         xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
      }else if(window.XMLHttpRequest){
         xmlHttp=new XMLHttpRequest();
      }
      
      return xmlHttp;
}
  