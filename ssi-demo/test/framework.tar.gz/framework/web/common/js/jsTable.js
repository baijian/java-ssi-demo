function getCell(tableObj, x, y) {
    x1 = x - 1;
    y1 = y - 1;
    var cellStr = tableObj.rows(x1).cells(y1).innerText;
    return cellStr;
}

function getCellHtml(tableObj, x, y) {
    x1 = x - 1;
    y1 = y - 1;
    var cellHtml = tableObj.rows(x1).cells(y1).innerHTML;
    return cellHtml;
}

function getCellObject(tableObj, x, y) {
    x1 = x - 1;
    y1 = y - 1;
    var cellObject = tableObj.rows(x1).cells(y1).childNodes[0];
    return cellObject;
}


function insertRow(tableObj, strArray) {
    newRow = tableObj.insertRow();
    newRow.className = "lowest";
    icol = tableObj.rows(0).cells.length;
    for (i = 0; i < icol; i++) {
        newRow.insertCell(i);
        newRow.cells(i).innerHTML = strArray[i];
    }    
}

function insertRow(tableObj, strArray, style) {
    newRow = tableObj.insertRow();
    newRow.className = "lowest";
    icol = tableObj.rows(0).cells.length;
    for (i = 0; i < icol; i++) {
        newRow.insertCell(i);
        newRow.cells(i).innerHTML = strArray[i];
    }
    if(style=='Y'){
    	newRow.style.color="#FF6633";
    }
}

function insertRowStyle(tableObj, strArray, style) {
    newRow = tableObj.insertRow();
    newRow.className = style;
    
    icol = tableObj.rows(0).cells.length;
    for (i = 0; i < icol; i++) {
        newRow.insertCell(i);
        newRow.cells(i).innerHTML = strArray[i];
        newRow.cells(i).align = "center";
    }
}

function delRow(tableObj, iRow) {
    iReal = iRow - 1;
    newRow = tableObj.deleteRow(iReal);
}

function updateRow(tableObj,strArray,iIndex){ 
    var j = iIndex-1;
    upRow = tableObj.rows(j);
    icol = tableObj.rows(0).cells.length;
   
    for(i=0;i<icol;i++){  
       upRow.cells(i).innerHTML=strArray[i];             
    }                                    
}
        
function updateRow(tableObj, strArray, iIndex, style){ 
    var j = iIndex-1;
    upRow = tableObj.rows(j);
    icol = tableObj.rows(0).cells.length;
    for(i=0;i<icol;i++){  
       upRow.cells(i).innerHTML=strArray[i];             
    }
    if(style=='Y'){
		upRow.style.color="#FF6633";
   	}else{
   		upRow.style.color="#000000";
   	}                                    
}

function updateCell(tableObj,str,iIndex,mIndex){ 
    var j = iIndex-1;
    var m = mIndex-1;
    upRow = tableObj.rows(j);
    upRow.cells(m).innerHTML=str;
}

function trim(str) {
	return str.replace(/^\s+|\s+$/g,"");
}