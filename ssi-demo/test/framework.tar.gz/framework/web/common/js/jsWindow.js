function winShow(ID, show) {
	if (show == null || typeof(show) == 'undefined') show = true;
	var el = document.getElementById(ID);
	if (el) {
		if (show) {
			el.style.visibility = "visible";
			var objLft = 0;
			var objTop = 0;
			for (var e = el; e.offsetParent; e = e.offsetParent) {
				objLft += e.offsetLeft;
				objTop += e.offsetTop;
			}
			var objRgt = objLft + el.offsetWidth;
			var objBtm = objTop + el.offsetHeight;
			var margin = 2;
			objLft -= margin; objTop -= margin;
			objRgt += margin; objBtm += margin;
			var winX = document.body.scrollLeft;
			var winY = document.body.scrollTop;
			var winW = document.body.clientWidth;
			var winH = document.body.clientHeight;
			if (objRgt > winX+winW) winX = objLft - winW;
			if (objBtm > winY+winH) winY = objBtm - winH;
			if (objLft < winX) winX = objLft;
			if (objTop < winY) winY = objTop;
			window.scrollTo(winX, winY);
		} else {
			el.style.visibility = "hidden";
		}
	}
}

function winHide(ID) {
	winShow(ID, false);
}

function winSetHeight(ID, height) {
	document.getElementById(ID).style.height = height + "px";
}
