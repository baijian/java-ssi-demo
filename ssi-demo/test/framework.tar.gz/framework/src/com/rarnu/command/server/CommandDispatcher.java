// ****************************************************
// * Ｒａｒｎｕ　Ｆｒａｍｅｗｏｒｋ　　　　　　　　　　　　　　  *
// *　　　Ｆｏｒ　Ｊ２ＥＥ　Ｗｉｔｈ　ＡＪＡＸ　Ｖ１．０　　 　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 本框架是基于ＳＴＲＵＴＳ，ＳＰＲＩＮＧ，ＨＩＢＥＲＮＡＴＥ  *
// * 进行构建的，适用于企业级Ｊ２ＥＥ开发，内部封装了ＡＪＡＸ，  *
// * ＤＯＪＯ等常用框架，能够使开发变得轻松，效率非常高。开发人  *
// * 员只需要遵守本框架的开发规则，就能创建出层次清晰，代码高质  *
// * 量，运行效果良好的网站系统。　　　　　　　　　　　　　　　  *
// *                                                  *
// * 本框架遵从ＭＰＬ协议，您可以任意的传播，使用，或修改本框架  *
// * ，使它更符合您的开发流程，但是不得抹去本框架原始作者的名字  *
// * 及版权信息。　　　　　　　　　　　　　　　　　　　　　　　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 框架开发：ＲａＲｎＵ　　　　　　　　　　　　　　　　　　　  *
// * 联系邮箱：ＶＩＶＡ＿ＫＩＬＬＥＲ＠１６３．ＣＯＭ　　　　　  *
// * 作者网站：ＨＴＴＰ：／／ＷＷＷ．ＢＵＧＵＡ．ＮＥＴ　　　　  *
// ****************************************************

package com.rarnu.command.server;

import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import javax.xml.transform.TransformerException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.context.WebApplicationContext;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.rarnu.command.core.Command;
import com.rarnu.consts.SystemConsts;
import com.rarnu.spring.SystemContext;
import com.rarnu.util.BeanUtils;
import com.rarnu.util.XmlHelper;
import com.sun.org.apache.xpath.internal.XPathAPI;

/**
 * 命令委托类
 * 
 * @author RaRnU ORZ
 * 
 */
public class CommandDispatcher {

	protected Log logger;

	private static Map<String, Command> commandMap = new HashMap<String, Command>();

	public CommandDispatcher() {
		logger = LogFactory.getLog(CommandDispatcher.class);
		InputStream inputStream = getClass().getResourceAsStream(
				SystemConsts.COMMAND_MAPPING);
		loadConfig(inputStream);
	}

	/**
	 * 获取 manager
	 * @param commandId 命令标识
	 * @return manager 对象
	 */
	protected Object getProcessor(String commandId) {
		Command command = getCommand(commandId);
		String processorInitMode = command.getMode();
		Object o = null;
		try {
			if (processorInitMode == null
					|| processorInitMode.length() == 0
					|| processorInitMode
							.equalsIgnoreCase(SystemConsts.MODE_BEAN))
				o = Class.forName(command.getProcessor()).newInstance();
			else if (!processorInitMode.equalsIgnoreCase(SystemConsts.MODE_EJB)
					&& processorInitMode
							.equalsIgnoreCase(SystemConsts.MODE_SPRING))
				o = SystemContext.getBeanFactory().getBean(
						command.getProcessor());
		} catch (Exception e) {
			logger.error((new StringBuilder(
					SystemConsts.STRING_BUILDER_PROCESSOR)).append(
					command.getProcessor()).append(
					String
							.format(SystemConsts.EXCEPTION_INFO,
									" create error!")).toString(), e);
		}
		return o;
	}

	protected Method getMethod(String commandId) {
		Class<?> aClass = getProcessor(commandId).getClass();
		return BeanUtils.getMethod(getCommand(commandId).getFunction(), aClass);
	}

	protected Command getCommand(String commandId) {
		Command command = (Command) commandMap.get(commandId);
		return command;
	}

	/**
	 * 载入配置文件
	 * @param inputStream
	 */
	public void loadConfig(InputStream inputStream) {
		Document document = XmlHelper.loadXML(inputStream);
		org.w3c.dom.Node root = document.getDocumentElement().getFirstChild();
		NodeList nodeList = null;
		if (root != null)
			try {
				nodeList = XPathAPI.selectNodeList(root,
						SystemConsts.COMMAND_MAPPING_ELEMENT);
			} catch (TransformerException e) {
				logger.error(String.format(SystemConsts.EXCEPTION_INFO,
						"Command config file load error!"), e);
				return;
			}
		if (nodeList != null) {
			for (int i = 0; i < nodeList.getLength(); i++) {
				org.w3c.dom.Node node = nodeList.item(i);
				Command command = new Command();
				command.setId(XmlHelper.getNodeAttr(node,
						SystemConsts.ELEMENT_ID));
				command.setProcessor(XmlHelper.getNodeAttr(node,
						SystemConsts.ELEMENT_PROCESSOR));
				command.setFunction(XmlHelper.getNodeAttr(node,
						SystemConsts.ELEMENT_FUNCTION));
				command.setMode(XmlHelper.getNodeAttr(node,
						SystemConsts.ELEMENT_INIT_MODE));
				commandMap.put(command.getId(), command);
			}

		}
	}

	protected Object getProcessor(String commandId,
			WebApplicationContext appContext) {
		Command command = getCommand(commandId);
		String processorInitMode = command.getMode();
		Object o = null;
		try {
			if (processorInitMode == null
					|| processorInitMode.length() == 0
					|| processorInitMode
							.equalsIgnoreCase(SystemConsts.MODE_BEAN))
				o = Class.forName(command.getProcessor()).newInstance();
			else if (!processorInitMode.equalsIgnoreCase(SystemConsts.MODE_EJB)
					&& processorInitMode
							.equalsIgnoreCase(SystemConsts.MODE_SPRING))
				o = appContext.getBean(command.getProcessor());
		} catch (Exception e) {
			logger.error((new StringBuilder(
					SystemConsts.STRING_BUILDER_PROCESSOR)).append(
					command.getProcessor()).append(
					String
							.format(SystemConsts.EXCEPTION_INFO,
									" create error!")).toString(), e);
		}
		return o;
	}

	protected Method getMethod(String commandId,
			WebApplicationContext appContext) {
		Class<?> aClass = getProcessor(commandId, appContext).getClass();
		return BeanUtils.getMethod(getCommand(commandId).getFunction(), aClass);
	}

}
