// ****************************************************
// * Ｒａｒｎｕ　Ｆｒａｍｅｗｏｒｋ　　　　　　　　　　　　　　  *
// *　　　Ｆｏｒ　Ｊ２ＥＥ　Ｗｉｔｈ　ＡＪＡＸ　Ｖ１．０　　 　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 本框架是基于ＳＴＲＵＴＳ，ＳＰＲＩＮＧ，ＨＩＢＥＲＮＡＴＥ  *
// * 进行构建的，适用于企业级Ｊ２ＥＥ开发，内部封装了ＡＪＡＸ，  *
// * ＤＯＪＯ等常用框架，能够使开发变得轻松，效率非常高。开发人  *
// * 员只需要遵守本框架的开发规则，就能创建出层次清晰，代码高质  *
// * 量，运行效果良好的网站系统。　　　　　　　　　　　　　　　  *
// *                                                  *
// * 本框架遵从ＭＰＬ协议，您可以任意的传播，使用，或修改本框架  *
// * ，使它更符合您的开发流程，但是不得抹去本框架原始作者的名字  *
// * 及版权信息。　　　　　　　　　　　　　　　　　　　　　　　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 框架开发：ＲａＲｎＵ　　　　　　　　　　　　　　　　　　　  *
// * 联系邮箱：ＶＩＶＡ＿ＫＩＬＬＥＲ＠１６３．ＣＯＭ　　　　　  *
// * 作者网站：ＨＴＴＰ：／／ＷＷＷ．ＢＵＧＵＡ．ＮＥＴ　　　　  *
// ****************************************************

package com.rarnu.command.server;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.context.WebApplicationContext;

import com.rarnu.command.core.CommandExecuteException;
import com.rarnu.command.core.ICommandServer;
import com.rarnu.consts.SystemConsts;

/**
 * 默认的命令服务类<br>
 * 当系统中未分配服务类时，自动调用此类
 * @author RaRnU ORZ
 *
 */
public class DefaultCommandServer extends AbstractCommandServer implements
		ICommandServer {

	public DefaultCommandServer() {
	}

	public Map<?,?> execute(String commondId, List<?> paramList)
			throws CommandExecuteException {
		Object processor = dispatcher.getProcessor(commondId);
		Method method = dispatcher.getMethod(commondId);
		if (method == null)
			throw new CommandExecuteException((new StringBuilder(
					String.format(SystemConsts.EXCEPTION_METHOD_NOT_FOUND, commondId)).toString()));
		Object o = null;
		Object params[] = (Object[]) null;
		if (paramList != null)
			params = paramList.toArray();
		try {
			o = method.invoke(processor, params);
			log();
		} catch (Exception e) {
			logger.error((new StringBuilder(SystemConsts.STRING_BUILDER_COMMAND)).append(commondId)
					.append(String.format(SystemConsts.EXCEPTION_INFO, " execute error!")).toString(), e);
			throw new CommandExecuteException((new StringBuilder(SystemConsts.STRING_BUILDER_COMMAND))
					.append(commondId).append(String.format(SystemConsts.EXCEPTION_INFO, " execute error!")).toString(), e);
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put(SystemConsts.COMMAND_EXECUTE_RESULT, o);
		return map;
	}

	public Map<?,?> execute(String commondId, List<?> paramList,
			WebApplicationContext appContext) throws CommandExecuteException {
		Object processor = dispatcher.getProcessor(commondId, appContext);
		Method method = dispatcher.getMethod(commondId, appContext);
		if (method == null)
			throw new CommandExecuteException((new StringBuilder(
					String.format(SystemConsts.EXCEPTION_METHOD_NOT_FOUND, commondId)).toString()));
		Object o = null;
		Object params[] = (Object[]) null;
		if (paramList != null)
			params = paramList.toArray();
		try {
			o = method.invoke(processor, params);
			log();
		} catch (Exception e) {
			logger.error((new StringBuilder(SystemConsts.STRING_BUILDER_COMMAND)).append(commondId)
					.append(String.format(SystemConsts.EXCEPTION_INFO, " execute error!")).toString(), e);
			throw new CommandExecuteException((new StringBuilder(SystemConsts.STRING_BUILDER_COMMAND))
					.append(commondId).append(String.format(SystemConsts.EXCEPTION_INFO, " execute error!")).toString(), e);
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put(SystemConsts.COMMAND_EXECUTE_RESULT, o);
		return map;
	}

	protected void log() {
	}
}
