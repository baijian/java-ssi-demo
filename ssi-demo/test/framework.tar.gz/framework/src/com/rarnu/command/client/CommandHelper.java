// ****************************************************
// * Ｒａｒｎｕ　Ｆｒａｍｅｗｏｒｋ　　　　　　　　　　　　　　  *
// *　　　Ｆｏｒ　Ｊ２ＥＥ　Ｗｉｔｈ　ＡＪＡＸ　Ｖ１．０　　 　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 本框架是基于ＳＴＲＵＴＳ，ＳＰＲＩＮＧ，ＨＩＢＥＲＮＡＴＥ  *
// * 进行构建的，适用于企业级Ｊ２ＥＥ开发，内部封装了ＡＪＡＸ，  *
// * ＤＯＪＯ等常用框架，能够使开发变得轻松，效率非常高。开发人  *
// * 员只需要遵守本框架的开发规则，就能创建出层次清晰，代码高质  *
// * 量，运行效果良好的网站系统。　　　　　　　　　　　　　　　  *
// *                                                  *
// * 本框架遵从ＭＰＬ协议，您可以任意的传播，使用，或修改本框架  *
// * ，使它更符合您的开发流程，但是不得抹去本框架原始作者的名字  *
// * 及版权信息。　　　　　　　　　　　　　　　　　　　　　　　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 框架开发：ＲａＲｎＵ　　　　　　　　　　　　　　　　　　　  *
// * 联系邮箱：ＶＩＶＡ＿ＫＩＬＬＥＲ＠１６３．ＣＯＭ　　　　　  *
// * 作者网站：ＨＴＴＰ：／／ＷＷＷ．ＢＵＧＵＡ．ＮＥＴ　　　　  *
// ****************************************************

package com.rarnu.command.client;

import com.rarnu.command.core.CommandExecuteException;
import com.rarnu.command.core.ICommandServer;
import com.rarnu.command.server.DefaultCommandServer;
import com.rarnu.consts.SystemConsts;

import java.util.List;
import java.util.Map;
import org.springframework.web.context.WebApplicationContext;

/**
 * 命令工具类<br>
 * 用于为 BaseAction 提供 facade 对象
 * @author RaRnU ORZ
 */
public class CommandHelper {

	private ICommandServer commandServer;
	
	public CommandHelper() {
	}

	protected ICommandServer getCommandServer() {
		if (commandServer == null)
			commandServer = new DefaultCommandServer();
		return commandServer;
	}

	public Object execute(String commandId, List<?> paramList)
			throws CommandExecuteException {
		Map<?,?> map = getCommandServer().execute(commandId, paramList);
		// 获取命令执行结果
		if (map != null)
			return map.get(SystemConsts.COMMAND_EXECUTE_RESULT);
		else
			return null;
	}

	public Object execute(String commandId, List<?> paramList,
			WebApplicationContext appContext) throws CommandExecuteException {
		Map<?,?> map = getCommandServer().execute(commandId, paramList, appContext);
		// 获取命令执行结果
		if (map != null)
			return map.get(SystemConsts.COMMAND_EXECUTE_RESULT);
		else
			return null;
	}

	
}
