// ****************************************************
// * Ｒａｒｎｕ　Ｆｒａｍｅｗｏｒｋ　　　　　　　　　　　　　　  *
// *　　　Ｆｏｒ　Ｊ２ＥＥ　Ｗｉｔｈ　ＡＪＡＸ　Ｖ１．０　　 　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 本框架是基于ＳＴＲＵＴＳ，ＳＰＲＩＮＧ，ＨＩＢＥＲＮＡＴＥ  *
// * 进行构建的，适用于企业级Ｊ２ＥＥ开发，内部封装了ＡＪＡＸ，  *
// * ＤＯＪＯ等常用框架，能够使开发变得轻松，效率非常高。开发人  *
// * 员只需要遵守本框架的开发规则，就能创建出层次清晰，代码高质  *
// * 量，运行效果良好的网站系统。　　　　　　　　　　　　　　　  *
// *                                                  *
// * 本框架遵从ＭＰＬ协议，您可以任意的传播，使用，或修改本框架  *
// * ，使它更符合您的开发流程，但是不得抹去本框架原始作者的名字  *
// * 及版权信息。　　　　　　　　　　　　　　　　　　　　　　　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 框架开发：ＲａＲｎＵ　　　　　　　　　　　　　　　　　　　  *
// * 联系邮箱：ＶＩＶＡ＿ＫＩＬＬＥＲ＠１６３．ＣＯＭ　　　　　  *
// * 作者网站：ＨＴＴＰ：／／ＷＷＷ．ＢＵＧＵＡ．ＮＥＴ　　　　  *
// ****************************************************

package com.rarnu.tag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;

import com.rarnu.consts.SystemConsts;

/**
 * 显示日期标签类
 * 
 * @author RaRnU ORZ
 * 
 */
public class ShowDateTag extends TagSupport {

	private static final long serialVersionUID = 1L;

	private String name;

	private String size;

	private String value;

	private String maxlength;

	private Boolean readonly;

	private String styleClass;

	private String id;

	public ShowDateTag() {

		super();
	}

	public void setMaxlength(String maxlength) {

		this.maxlength = maxlength;
	}

	public void setName(String name) throws Exception {

		this.name = name;
	}

	public void setReadonly(boolean readonly) {

		this.readonly = readonly;
	}

	private boolean isNull() {

		return (this.name == null || this.name.equals(SystemConsts.MARK_NULL)) ? true : false;

	}

	public void setSize(String size) {

		this.size = size;
	}

	public void setStyleClass(String styleClass) {

		this.styleClass = styleClass;
	}

	public int doStartTag() throws JspException {

		JspWriter out = pageContext.getOut();

		if (this.isNull())
			throw new JspException(
					String
							.format(SystemConsts.EXCEPTION_INFO,
									" this name property must input a value ! required proerty!"));

		try {
			StringBuffer str = new StringBuffer();
			
			str.append("<input type=text ");

			str.append(" name='" + this.name + SystemConsts.SQL_SINGLE_QUOTE);

			if (this.size != null)
				str.append(" size='" + this.size + SystemConsts.SQL_SINGLE_QUOTE);
			if (this.maxlength != null)
				str.append(" maxlength='" + this.maxlength + SystemConsts.SQL_SINGLE_QUOTE);
			if (this.readonly != null)
				str.append(" readonly='" + this.readonly + SystemConsts.SQL_SINGLE_QUOTE);
			if (this.styleClass != null)
				str.append(" class='" + this.styleClass + SystemConsts.SQL_SINGLE_QUOTE);

			if (this.value != null)
				str.append(" value=\"" + this.value + "\"");

			if (this.id != null)
				str.append(" id='" + this.id + SystemConsts.SQL_SINGLE_QUOTE);

			str.append(" onclick=\"return showCalendar(this,'y-mm-dd');\" />");

			out.println(str.toString());
		} catch (IOException e) {
			e.printStackTrace(System.err);
			try {
				out.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}

		return SKIP_BODY;
	}

	public void setValue(String value) {

		try {
			String str = (String) ExpressionEvaluatorManager.evaluate(
					SystemConsts.STR_VALUE, value, String.class, this,
					pageContext);
			if (str != null && !str.equals(SystemConsts.MARK_NULL) && str.length() > 10)
				str = str.substring(0, 10);
			this.value = str;
		} catch (JspException e) {

			e.printStackTrace();
		}
	}

	public String getId() {

		return this.id;
	}

	public void setId(String id) {

		this.id = id;
	}

}
