// ****************************************************
// * Ｒａｒｎｕ　Ｆｒａｍｅｗｏｒｋ　　　　　　　　　　　　　　  *
// *　　　Ｆｏｒ　Ｊ２ＥＥ　Ｗｉｔｈ　ＡＪＡＸ　Ｖ１．０　　 　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 本框架是基于ＳＴＲＵＴＳ，ＳＰＲＩＮＧ，ＨＩＢＥＲＮＡＴＥ  *
// * 进行构建的，适用于企业级Ｊ２ＥＥ开发，内部封装了ＡＪＡＸ，  *
// * ＤＯＪＯ等常用框架，能够使开发变得轻松，效率非常高。开发人  *
// * 员只需要遵守本框架的开发规则，就能创建出层次清晰，代码高质  *
// * 量，运行效果良好的网站系统。　　　　　　　　　　　　　　　  *
// *                                                  *
// * 本框架遵从ＭＰＬ协议，您可以任意的传播，使用，或修改本框架  *
// * ，使它更符合您的开发流程，但是不得抹去本框架原始作者的名字  *
// * 及版权信息。　　　　　　　　　　　　　　　　　　　　　　　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 框架开发：ＲａＲｎＵ　　　　　　　　　　　　　　　　　　　  *
// * 联系邮箱：ＶＩＶＡ＿ＫＩＬＬＥＲ＠１６３．ＣＯＭ　　　　　  *
// * 作者网站：ＨＴＴＰ：／／ＷＷＷ．ＢＵＧＵＡ．ＮＥＴ　　　　  *
// ****************************************************

package com.rarnu.tag;

import org.apache.commons.beanutils.PropertyUtils;

import com.rarnu.consts.SystemConsts;

import javax.servlet.jsp.PageContext;

/**
 * 工具标签类
 * @author RaRnU ORZ
 *
 */
public class UtilsTag {

	public static Object lookup(PageContext pageContext, String beanName,
			String prop) {
		Object bean = pageContext.findAttribute(beanName);

		try {
			if (bean != null) {
				if (prop == null) {
					return bean;
				} else {
					return bean = PropertyUtils.getProperty(bean, prop);
				}
			} else {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	public static Object lookup(PageContext pageContext, String access) {
		if (access == null)
			return null;
		int ind = access.indexOf(SystemConsts.SQL_DOT);
		if (ind == -1)
			return lookup(pageContext, access, null);

		String name = access.substring(0, ind);
		String property = access.substring(ind + 1);

		return lookup(pageContext, name, property);
	}

}
