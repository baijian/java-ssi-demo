// ****************************************************
// * Ｒａｒｎｕ　Ｆｒａｍｅｗｏｒｋ　　　　　　　　　　　　　　  *
// *　　　Ｆｏｒ　Ｊ２ＥＥ　Ｗｉｔｈ　ＡＪＡＸ　Ｖ１．０　　 　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 本框架是基于ＳＴＲＵＴＳ，ＳＰＲＩＮＧ，ＨＩＢＥＲＮＡＴＥ  *
// * 进行构建的，适用于企业级Ｊ２ＥＥ开发，内部封装了ＡＪＡＸ，  *
// * ＤＯＪＯ等常用框架，能够使开发变得轻松，效率非常高。开发人  *
// * 员只需要遵守本框架的开发规则，就能创建出层次清晰，代码高质  *
// * 量，运行效果良好的网站系统。　　　　　　　　　　　　　　　  *
// *                                                  *
// * 本框架遵从ＭＰＬ协议，您可以任意的传播，使用，或修改本框架  *
// * ，使它更符合您的开发流程，但是不得抹去本框架原始作者的名字  *
// * 及版权信息。　　　　　　　　　　　　　　　　　　　　　　　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 框架开发：ＲａＲｎＵ　　　　　　　　　　　　　　　　　　　  *
// * 联系邮箱：ＶＩＶＡ＿ＫＩＬＬＥＲ＠１６３．ＣＯＭ　　　　　  *
// * 作者网站：ＨＴＴＰ：／／ＷＷＷ．ＢＵＧＵＡ．ＮＥＴ　　　　  *
// ****************************************************

package com.rarnu.persistence;

import java.util.*;
import org.hibernate.*;

import com.rarnu.consts.SystemConsts;

/**
 * 分页工具类
 * @author RaRnU ORZ
 *
 */
public class PagerHelper {

	public PagerHelper() {
	}

	public int getQuerySize(Session session, Query query)
			throws HibernateException {
		String queryString = query.getQueryString();
		queryString = parseQuerystring(queryString);
		queryString = removeOrderBy(queryString);
		List<?> list = null;
		Query queryCount = null;
		queryCount = session.createQuery(queryString);
		list = queryCount.list();
		if (list != null && list.size() > 0)
			return ((Integer) list.get(0)).intValue();
		else
			return 0;
	}

	public int getQuerySize(Session session, Query query, Map<?, ?> paramMap)
			throws HibernateException {
		String queryString = query.getQueryString();
		queryString = parseQuerystring(queryString);
		queryString = removeOrderBy(queryString);
		queryString = removeGroupBy(queryString);
		List<?> list = null;
		Query queryCount = null;
		queryCount = session.createQuery(queryString);
		if (paramMap != null && paramMap.size() > 0) {
			Iterator<?> iterator = paramMap.keySet().iterator();
			String paramName = null;
			Object paramValue = null;
			for (; iterator.hasNext(); queryCount.setParameter(paramName,
					paramValue)) {
				paramName = (String) iterator.next();
				paramValue = paramMap.get(paramName);
			}

		}
		list = queryCount.list();
		if (list != null && list.size() > 0)
			return ((Integer) list.get(0)).intValue();
		else
			return 0;
	}

	protected String parseQuerystring(String hql) {
		String hqlUpper = hql.toUpperCase();
		int indexFrom = hqlUpper.indexOf(SystemConsts.SQL_FROM);
		int indexComma = hqlUpper.indexOf(SystemConsts.SQL_COMMA);
		int indexDistinct = hqlUpper.indexOf(SystemConsts.SQL_DISTINCT);
		if (indexFrom > -1)
			if (indexDistinct > -1) {
				String strDistinct = hql.substring(indexDistinct, indexComma);
				hql = (new StringBuilder(String.format(SystemConsts.SQL_SELECT_FIELD, strDistinct)).append(
								hql.substring(indexFrom))).toString();
			} else {
				hql = (new StringBuilder(SystemConsts.SQL_SELECT_ALL)).append(
						hql.substring(indexFrom)).toString();
			}
		return hql;
	}

	protected String removeOrderBy(String sql) {
		int index = sql.indexOf(SystemConsts.SQL_ORDER_UPPER);
		if (index < 1)
			index = sql.indexOf(SystemConsts.SQL_ORDER_LOWER);
		if (index > 0)
			return sql.substring(0, index);
		else
			return sql;
	}

	protected String removeGroupBy(String sql) {
		int index = sql.indexOf(SystemConsts.SQL_GRUOP_UPPER);
		if (index < 1)
			index = sql.indexOf(SystemConsts.SQL_GRUOP_LOWER);
		if (index > 0)
			return sql.substring(0, index);
		else
			return sql;
	}
}
