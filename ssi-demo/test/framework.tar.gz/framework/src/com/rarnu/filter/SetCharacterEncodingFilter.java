// ****************************************************
// * Ｒａｒｎｕ　Ｆｒａｍｅｗｏｒｋ　　　　　　　　　　　　　　  *
// *　　　Ｆｏｒ　Ｊ２ＥＥ　Ｗｉｔｈ　ＡＪＡＸ　Ｖ１．０　　 　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 本框架是基于ＳＴＲＵＴＳ，ＳＰＲＩＮＧ，ＨＩＢＥＲＮＡＴＥ  *
// * 进行构建的，适用于企业级Ｊ２ＥＥ开发，内部封装了ＡＪＡＸ，  *
// * ＤＯＪＯ等常用框架，能够使开发变得轻松，效率非常高。开发人  *
// * 员只需要遵守本框架的开发规则，就能创建出层次清晰，代码高质  *
// * 量，运行效果良好的网站系统。　　　　　　　　　　　　　　　  *
// *                                                  *
// * 本框架遵从ＭＰＬ协议，您可以任意的传播，使用，或修改本框架  *
// * ，使它更符合您的开发流程，但是不得抹去本框架原始作者的名字  *
// * 及版权信息。　　　　　　　　　　　　　　　　　　　　　　　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 框架开发：ＲａＲｎＵ　　　　　　　　　　　　　　　　　　　  *
// * 联系邮箱：ＶＩＶＡ＿ＫＩＬＬＥＲ＠１６３．ＣＯＭ　　　　　  *
// * 作者网站：ＨＴＴＰ：／／ＷＷＷ．ＢＵＧＵＡ．ＮＥＴ　　　　  *
// ****************************************************

package com.rarnu.filter;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.*;

import javax.servlet.*;

import com.rarnu.consts.SystemConsts;

/**
 * 字符编码格式过滤器类
 * @author RaRnU ORZ
 *
 */
public class SetCharacterEncodingFilter implements Filter {

	protected String encoding;

	protected FilterConfig filterConfig;

	protected boolean ignore;
	
	public SetCharacterEncodingFilter() {
		encoding = null;
		filterConfig = null;
		ignore = true;
	}

	public void destroy() {
		encoding = null;
		filterConfig = null;
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		request.setCharacterEncoding(SystemConsts.CHARSET_GB2312);
		chain.doFilter(request, response);
	}

	@SuppressWarnings("unchecked")
	protected void processRequestParameters(ServletRequest request) {
	
		Map parameterMap = request.getParameterMap();
		Map map = parameterMap;
		if (map == null)
			return;
		Set set = map.keySet();
		if (set == null)
			return;
		Iterator iterator = set.iterator();
		String para = null;
		String paras[] = (String[]) null;
		while (iterator.hasNext()) {
			Object o = iterator.next();
			paras = (String[]) map.get(o);
			if (paras != null && paras.length > 0) {
				try {
					para = paras[0];
					para = new String(para.getBytes(SystemConsts.CHARSET_ISO),
							selectEncoding(request));
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				}
				map.put(o, para);
			}
		}
	}

	public void init(FilterConfig filterConfig) throws ServletException {
		this.filterConfig = filterConfig;
		encoding = filterConfig.getInitParameter(SystemConsts.CHARSET_ENCODING);
		String value = filterConfig.getInitParameter(SystemConsts.CHARSET_IGNORE);
		if (value == null)
			ignore = true;
		else if (value.equalsIgnoreCase(SystemConsts.STR_TRUE))
			ignore = true;
		else if (value.equalsIgnoreCase(SystemConsts.STR_YES))
			ignore = true;
		else
			ignore = false;
	}

	protected String selectEncoding(ServletRequest request) {
		return encoding;
	}

	
}
