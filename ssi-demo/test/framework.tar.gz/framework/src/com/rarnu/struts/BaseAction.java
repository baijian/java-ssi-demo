// ****************************************************
// * Ｒａｒｎｕ　Ｆｒａｍｅｗｏｒｋ　　　　　　　　　　　　　　  *
// *　　　Ｆｏｒ　Ｊ２ＥＥ　Ｗｉｔｈ　ＡＪＡＸ　Ｖ１．０　　 　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 本框架是基于ＳＴＲＵＴＳ，ＳＰＲＩＮＧ，ＨＩＢＥＲＮＡＴＥ  *
// * 进行构建的，适用于企业级Ｊ２ＥＥ开发，内部封装了ＡＪＡＸ，  *
// * ＤＯＪＯ等常用框架，能够使开发变得轻松，效率非常高。开发人  *
// * 员只需要遵守本框架的开发规则，就能创建出层次清晰，代码高质  *
// * 量，运行效果良好的网站系统。　　　　　　　　　　　　　　　  *
// *                                                  *
// * 本框架遵从ＭＰＬ协议，您可以任意的传播，使用，或修改本框架  *
// * ，使它更符合您的开发流程，但是不得抹去本框架原始作者的名字  *
// * 及版权信息。　　　　　　　　　　　　　　　　　　　　　　　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 框架开发：ＲａＲｎＵ　　　　　　　　　　　　　　　　　　　  *
// * 联系邮箱：ＶＩＶＡ＿ＫＩＬＬＥＲ＠１６３．ＣＯＭ　　　　　  *
// * 作者网站：ＨＴＴＰ：／／ＷＷＷ．ＢＵＧＵＡ．ＮＥＴ　　　　  *
// ****************************************************

package com.rarnu.struts;

import java.lang.reflect.Field;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.rarnu.Pager;
import com.rarnu.command.client.CommandHelper;
import com.rarnu.consts.SystemConsts;
import com.rarnu.spring.SystemContext;

/**
 * 基础 action 类
 * @author RaRnU ORZ
 *
 */
public abstract class BaseAction extends Action {

	protected ApplicationContext context;

	protected CommandHelper facade;
	
	public BaseAction() {
	}

	public final ActionForward execute(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse httpServletResponse) throws Exception {
		
//		Enumeration enu = request.getAttributeNames();
//		while(enu.hasMoreElements()){
//			String eleName = (String)enu.nextElement();
//			String eleValue = request.getParameter(eleName);
//			eleValue = UtilString.Utf8ToGbk(eleValue).trim();
//			request.setAttribute(eleName, eleValue);
//		}
		
		return execute2(actionMapping, actionForm, request, httpServletResponse);
	}

	protected abstract ActionForward execute2(ActionMapping actionmapping,
			ActionForm actionform, HttpServletRequest httpservletrequest,
			HttpServletResponse httpservletresponse) throws Exception;

	public void setServlet(ActionServlet actionServlet) {
		super.setServlet(actionServlet);
		if (context == null) {
			context = WebApplicationContextUtils
					.getRequiredWebApplicationContext(actionServlet
							.getServletContext());
			facade = (CommandHelper) context.getBean(SystemConsts.COMMAND_HELPER);
			SystemContext.setApplicationContext(context);
		}
	}

	protected Pager getPager(HttpServletRequest request, int pageSize) {
		int pagenum = 1;
		try {
			pagenum = Integer
					.parseInt(request.getParameter(SystemConsts.CURRENT_PAGE_NUM));
		} catch (NumberFormatException e) {
			pagenum = 1;
		}
		Pager pager = new Pager(pagenum, pageSize);
		return pager;
	}

	public void populateQueryForm(Object queryForm, HttpServletRequest request)
			throws Exception {
		String queryStr = request.getQueryString();
		if (queryStr == null)
			return;
		queryStr = URLDecoder.decode(queryStr, SystemConsts.CHARSET_UTF_8);
		String paramArray[] = queryStr.split(SystemConsts.SQL_AND_CHAR);
		Map<String, Object> mapParams = new HashMap<String, Object>();
		for (int i = 0; i < paramArray.length; i++) {
			String paramStr = paramArray[i];
			String singleParamArray[] = paramStr.split(SystemConsts.SQL_EQUAL);
			int singlParaStrLength = singleParamArray.length;
			mapParams.put(singleParamArray[0], singlParaStrLength != 2 ? null
					: ((Object) (singleParamArray[1])));
		}

		boolean isAllFieldValuesNull = true;
		Class<?> clazz = queryForm.getClass();
		Field fields[] = clazz.getDeclaredFields();
		for (int i = 0; i < fields.length; i++) {
			Field field = fields[i];
			String fieldName = field.getName();
			if (!fieldName.equals(SystemConsts.PRICE_1) && !fieldName.equals(SystemConsts.PRICE_2)) {
				String fieldValue = (String) mapParams.get(fieldName);
				field.setAccessible(true);
				field.set(queryForm, fieldValue);
			}
		}

		Object fieldVlueObject = mapParams.get(SystemConsts.CURRENT_PAGE_NUM);
		if (fieldVlueObject != null) {
			isAllFieldValuesNull = false;
			if (mapParams.get(SystemConsts.Q_FOR_WHAT) != null)
				request.setAttribute(SystemConsts.Q_FOR_WHAT, mapParams.get(SystemConsts.Q_FOR_WHAT));
			if (mapParams.get(SystemConsts.Q_FILL) != null)
				request.setAttribute(SystemConsts.Q_FILL, mapParams.get(SystemConsts.Q_FILL));
		}
		String currentPageNum = (String) mapParams.get(SystemConsts.CURRENT_PAGE_NUM);
		if (currentPageNum == null)
			currentPageNum = "1";
		request.setAttribute(SystemConsts.CURRENT_PAGE_NUM, currentPageNum);
		if (!isAllFieldValuesNull)
			request.setAttribute(SystemConsts.Q_RETURN_QUERY, SystemConsts.STR_TRUE);
	}

	
}
