// ****************************************************
// * Ｒａｒｎｕ　Ｆｒａｍｅｗｏｒｋ　　　　　　　　　　　　　　  *
// *　　　Ｆｏｒ　Ｊ２ＥＥ　Ｗｉｔｈ　ＡＪＡＸ　Ｖ１．０　　 　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 本框架是基于ＳＴＲＵＴＳ，ＳＰＲＩＮＧ，ＨＩＢＥＲＮＡＴＥ  *
// * 进行构建的，适用于企业级Ｊ２ＥＥ开发，内部封装了ＡＪＡＸ，  *
// * ＤＯＪＯ等常用框架，能够使开发变得轻松，效率非常高。开发人  *
// * 员只需要遵守本框架的开发规则，就能创建出层次清晰，代码高质  *
// * 量，运行效果良好的网站系统。　　　　　　　　　　　　　　　  *
// *                                                  *
// * 本框架遵从ＭＰＬ协议，您可以任意的传播，使用，或修改本框架  *
// * ，使它更符合您的开发流程，但是不得抹去本框架原始作者的名字  *
// * 及版权信息。　　　　　　　　　　　　　　　　　　　　　　　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 框架开发：ＲａＲｎＵ　　　　　　　　　　　　　　　　　　　  *
// * 联系邮箱：ＶＩＶＡ＿ＫＩＬＬＥＲ＠１６３．ＣＯＭ　　　　　  *
// * 作者网站：ＨＴＴＰ：／／ＷＷＷ．ＢＵＧＵＡ．ＮＥＴ　　　　  *
// ****************************************************

package com.rarnu.struts;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.*;

import com.rarnu.consts.SystemConsts;

/**
 * 基础 actionForm 类
 * @author RaRnU ORZ
 *
 */
public class BaseActionForm extends ActionForm {
	private static final long serialVersionUID = 1L;

	public BaseActionForm() {
	}

	public ActionErrors validate(ActionMapping mapping,
			HttpServletRequest request) {
		ActionErrors actionErrors = null;
		ArrayList<Object> errorList = new ArrayList<Object>();
		doValidate(mapping, request, errorList);
		request.setAttribute(SystemConsts.STR_ERRORS, errorList);
		if (!errorList.isEmpty()) {
			actionErrors = new ActionErrors();
			actionErrors.add(SystemConsts.GLOBAL_ERROR_CLASS,
					new ActionError(SystemConsts.GLOBAL_ERROR_STR));
		}
		return actionErrors;
	}

	public void doValidate(ActionMapping actionmapping,
			HttpServletRequest httpservletrequest, List<?> list) {
	}

	protected void addErrorIfStringEmpty(List<String> errors, String message,
			String value) {
		if (value == null || value.trim().length() < 1)
			errors.add(message);
	}
}
