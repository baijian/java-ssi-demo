// ****************************************************
// * Ｒａｒｎｕ　Ｆｒａｍｅｗｏｒｋ　　　　　　　　　　　　　　  *
// *　　　Ｆｏｒ　Ｊ２ＥＥ　Ｗｉｔｈ　ＡＪＡＸ　Ｖ１．０　　 　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 本框架是基于ＳＴＲＵＴＳ，ＳＰＲＩＮＧ，ＨＩＢＥＲＮＡＴＥ  *
// * 进行构建的，适用于企业级Ｊ２ＥＥ开发，内部封装了ＡＪＡＸ，  *
// * ＤＯＪＯ等常用框架，能够使开发变得轻松，效率非常高。开发人  *
// * 员只需要遵守本框架的开发规则，就能创建出层次清晰，代码高质  *
// * 量，运行效果良好的网站系统。　　　　　　　　　　　　　　　  *
// *                                                  *
// * 本框架遵从ＭＰＬ协议，您可以任意的传播，使用，或修改本框架  *
// * ，使它更符合您的开发流程，但是不得抹去本框架原始作者的名字  *
// * 及版权信息。　　　　　　　　　　　　　　　　　　　　　　　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 框架开发：ＲａＲｎＵ　　　　　　　　　　　　　　　　　　　  *
// * 联系邮箱：ＶＩＶＡ＿ＫＩＬＬＥＲ＠１６３．ＣＯＭ　　　　　  *
// * 作者网站：ＨＴＴＰ：／／ＷＷＷ．ＢＵＧＵＡ．ＮＥＴ　　　　  *
// ****************************************************

package com.rarnu.hibernate;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.rarnu.consts.SystemConsts;

/**
 * 抽象的持久化对象类
 * @author RaRnU ORZ
 *
 */
public abstract class AbstractPersistenceObject implements Serializable,
		PropertyChangeListener {

	private static final long serialVersionUID = 1L;

	private PropertyChangeSupport support;

	private Map<String, Object> originalValues;

	private Map<String, Object> newValues;
	
	public AbstractPersistenceObject() {
		support = new PropertyChangeSupport(this);
		originalValues = new HashMap<String, Object>();
		newValues = new HashMap<String, Object>();
		addPropertyChangeListener(new PropertyChangeListener() {

			public void propertyChange(PropertyChangeEvent evt) {
				System.out.println(evt.getPropertyName());
				System.out.println(evt.getPropertyName());
			}

		});
	}

	public Map<String, Object> getOriginalState() {
		return originalValues;
	}

	public Map<String, Object> getNewState() {
		return newValues;
	}

	public void addPropertyChangeListener(
			PropertyChangeListener propertyChangeListener) {
		support.addPropertyChangeListener(propertyChangeListener);
	}

	protected void firePropertyChange(String property, Object oldValue,
			Object newValue) {
		if (!originalValues.containsKey(property)) {
			originalValues.put(property, oldValue);
			newValues.put(property, newValue);
		}
		support.firePropertyChange(property, oldValue, newValue);
	}

	public void propertyChange(PropertyChangeEvent evt) {
		System.out.println((new StringBuilder(String.valueOf(evt
				.getPropertyName()))).append(SystemConsts.STR_CHANGED).toString());
	}

	
}
