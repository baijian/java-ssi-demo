// ****************************************************
// * Ｒａｒｎｕ　Ｆｒａｍｅｗｏｒｋ　　　　　　　　　　　　　　  *
// *　　　Ｆｏｒ　Ｊ２ＥＥ　Ｗｉｔｈ　ＡＪＡＸ　Ｖ１．０　　 　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 本框架是基于ＳＴＲＵＴＳ，ＳＰＲＩＮＧ，ＨＩＢＥＲＮＡＴＥ  *
// * 进行构建的，适用于企业级Ｊ２ＥＥ开发，内部封装了ＡＪＡＸ，  *
// * ＤＯＪＯ等常用框架，能够使开发变得轻松，效率非常高。开发人  *
// * 员只需要遵守本框架的开发规则，就能创建出层次清晰，代码高质  *
// * 量，运行效果良好的网站系统。　　　　　　　　　　　　　　　  *
// *                                                  *
// * 本框架遵从ＭＰＬ协议，您可以任意的传播，使用，或修改本框架  *
// * ，使它更符合您的开发流程，但是不得抹去本框架原始作者的名字  *
// * 及版权信息。　　　　　　　　　　　　　　　　　　　　　　　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 框架开发：ＲａＲｎＵ　　　　　　　　　　　　　　　　　　　  *
// * 联系邮箱：ＶＩＶＡ＿ＫＩＬＬＥＲ＠１６３．ＣＯＭ　　　　　  *
// * 作者网站：ＨＴＴＰ：／／ＷＷＷ．ＢＵＧＵＡ．ＮＥＴ　　　　  *
// ****************************************************

package com.rarnu.util;

import java.util.HashMap;
import java.util.Map;

import com.rarnu.Pager;
import com.rarnu.consts.SystemConsts;

/**
 * Manager 工具类
 * 
 * @author RaRnU ORZ
 * 
 */
public class UtilBusiness {

	public static Map<?,?> returnValue(Object obj) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put(SystemConsts.VALUE, obj);
		return map;
	}

	public static Object getValue(Map<?,?> m) {
		return m.get(SystemConsts.VALUE);
	}

	public static boolean isReturnValue(Map<?,?> m) {
		Object obj = m.get(SystemConsts.VALUE);
		if (obj == null)
			return false;
		else
			return true;
	}

	public static Map<String, Object> returnSuccess() {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put(SystemConsts.RESULT, SystemConsts.RESULT_SUCCESS);
		return map;
	}

	public static Map<?,?> returnSuccess(String msg) {
		Map<String, String> map = new HashMap<String, String>();
		map.put(SystemConsts.RESULT, SystemConsts.RESULT_SUCCESS);
		map.put(SystemConsts.MSG, msg);
		return map;
	}

	public static boolean isSuccess(Map<?,?> map) {
		if (SystemConsts.RESULT_SUCCESS.equals(map.get(SystemConsts.RESULT))) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean isError(Map<?,?> map) {
		if (SystemConsts.RESULT_ERROR.equals(map.get(SystemConsts.RESULT))) {
			return true;
		} else {
			return false;
		}
	}

	public static Map<?,?> returnWarn() {
		Map<String, String> map = new HashMap<String, String>();
		map.put(SystemConsts.RESULT, SystemConsts.RESULT_WARN);
		return map;
	}

	public static boolean isWarn(Map<?,?> map) {
		if (SystemConsts.RESULT_WARN.equals(map.get(SystemConsts.RESULT))) {
			return true;
		} else {
			return false;
		}
	}

	public static Map<?,?> returnWarn(String msgkey) {
		Map<String, String> map = new HashMap<String, String>();
		map.put(SystemConsts.RESULT, SystemConsts.RESULT_WARN);
		map.put(SystemConsts.MSG, msgkey);
		return map;
	}

	public static Map<?,?> returnWarn(String msgkey, String msg2) {
		Map<String, String> map = new HashMap<String, String>();
		map.put(SystemConsts.RESULT, SystemConsts.RESULT_WARN);
		map.put(SystemConsts.MSG, msgkey);
		map.put(SystemConsts.MSG2, msg2);
		return map;
	}

	public static Map<?,?> returnError() {
		Map<String, String> map = new HashMap<String, String>();
		map.put(SystemConsts.RESULT, SystemConsts.RESULT_ERROR);
		return map;
	}

	public static Map<?,?> returnError(String msg) {
		Map<String, String> map = new HashMap<String, String>();
		map.put(SystemConsts.RESULT, SystemConsts.RESULT_ERROR);
		map.put(SystemConsts.MSG, msg);
		return map;
	}

	public static String getMsgInit(Map<?,?> map) {
		String msg = (String) map.get(SystemConsts.MSG);
		return msg;
	}

	public static String getMsgKey(Map<?,?> map) {
		String key = (String) map.get(SystemConsts.MSG);
		return key;
	}

	public static void returnValue(Map<String,Object> map, Object returnValue) {
		map.put(SystemConsts.RETURN, returnValue);
	}

	public static Object getReturn(Map<?, ?> map) {
		return map.get(SystemConsts.RETURN);
	}

	public static Pager getPager(Map<?,?> map) {
		return (Pager) map.get(SystemConsts.PAGER);
	}

	public static void setPager(Map<String, Object> map, Pager pager) {
		map.put(SystemConsts.PAGER, pager);
	}
}
