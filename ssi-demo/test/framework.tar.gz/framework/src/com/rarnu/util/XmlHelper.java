// ****************************************************
// * Ｒａｒｎｕ　Ｆｒａｍｅｗｏｒｋ　　　　　　　　　　　　　　  *
// *　　　Ｆｏｒ　Ｊ２ＥＥ　Ｗｉｔｈ　ＡＪＡＸ　Ｖ１．０　　 　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 本框架是基于ＳＴＲＵＴＳ，ＳＰＲＩＮＧ，ＨＩＢＥＲＮＡＴＥ  *
// * 进行构建的，适用于企业级Ｊ２ＥＥ开发，内部封装了ＡＪＡＸ，  *
// * ＤＯＪＯ等常用框架，能够使开发变得轻松，效率非常高。开发人  *
// * 员只需要遵守本框架的开发规则，就能创建出层次清晰，代码高质  *
// * 量，运行效果良好的网站系统。　　　　　　　　　　　　　　　  *
// *                                                  *
// * 本框架遵从ＭＰＬ协议，您可以任意的传播，使用，或修改本框架  *
// * ，使它更符合您的开发流程，但是不得抹去本框架原始作者的名字  *
// * 及版权信息。　　　　　　　　　　　　　　　　　　　　　　　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 框架开发：ＲａＲｎＵ　　　　　　　　　　　　　　　　　　　  *
// * 联系邮箱：ＶＩＶＡ＿ＫＩＬＬＥＲ＠１６３．ＣＯＭ　　　　　  *
// * 作者网站：ＨＴＴＰ：／／ＷＷＷ．ＢＵＧＵＡ．ＮＥＴ　　　　  *
// ****************************************************

package com.rarnu.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.sun.org.apache.xpath.internal.XPathAPI;

/**
 * xml 操作工具类
 * 
 * @author RaRnU ORZ
 * 
 */
public class XmlHelper {

	private static Log logger;

	private static DocumentBuilderFactory dbf;

	private static DocumentBuilder builder;

	static {
		logger = LogFactory.getLog(XmlHelper.class);
		try {
			dbf = DocumentBuilderFactory.newInstance();
			builder = dbf.newDocumentBuilder();
		} catch (FactoryConfigurationError factoryConfigurationError) {
			factoryConfigurationError.printStackTrace();
		} catch (ParserConfigurationException e) {
			logger.error(e);
		}
	}
	
	private XmlHelper() {
	}

	public static Document loadXML(File file) {
		Document document = null;
		if (dbf == null || builder == null)
			return null;
		try {
			document = builder.parse(file);
		} catch (Exception e) {
			logger.error(e);
		}
		return document;
	}

	public static synchronized Document loadXML(InputStream stream) {
		Document document = null;
		if (dbf == null || builder == null)
			return null;
		try {
			document = builder.parse(stream);
		} catch (SAXException e) {
			logger.error(e);
		} catch (IOException e) {
			logger.error(e);
		}
		return document;
	}

	public static Document loadXML(String fileClassPath) {
		InputStream inputStream = Class.class
				.getResourceAsStream(fileClassPath);
		return loadXML(inputStream);
	}

	public static String getNodeAttr(Node node, String attr) {
		if (node == null)
			return null;
		Node node2 = node.getAttributes().getNamedItem(attr);
		if (node2 == null)
			return null;
		else
			return node2.getNodeValue();
	}

	public static String getSubnodeValue(Node parent, String subnode) {
		if (parent == null || subnode == null || subnode.trim().length() == 0)
			return null;
		String value = null;
		Node nodeSub = null;
		try {
			nodeSub = XPathAPI.selectSingleNode(parent, subnode);
		} catch (TransformerException e) {
			return null;
		}
		if (nodeSub != null && nodeSub.getFirstChild() != null) {
			value = nodeSub.getFirstChild().getNodeValue();
			if (value != null)
				value = value.trim();
		}
		return value;
	}

	
}
