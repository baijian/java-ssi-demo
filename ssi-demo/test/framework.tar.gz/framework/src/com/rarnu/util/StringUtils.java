// ****************************************************
// * Ｒａｒｎｕ　Ｆｒａｍｅｗｏｒｋ　　　　　　　　　　　　　　  *
// *　　　Ｆｏｒ　Ｊ２ＥＥ　Ｗｉｔｈ　ＡＪＡＸ　Ｖ１．０　　 　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 本框架是基于ＳＴＲＵＴＳ，ＳＰＲＩＮＧ，ＨＩＢＥＲＮＡＴＥ  *
// * 进行构建的，适用于企业级Ｊ２ＥＥ开发，内部封装了ＡＪＡＸ，  *
// * ＤＯＪＯ等常用框架，能够使开发变得轻松，效率非常高。开发人  *
// * 员只需要遵守本框架的开发规则，就能创建出层次清晰，代码高质  *
// * 量，运行效果良好的网站系统。　　　　　　　　　　　　　　　  *
// *                                                  *
// * 本框架遵从ＭＰＬ协议，您可以任意的传播，使用，或修改本框架  *
// * ，使它更符合您的开发流程，但是不得抹去本框架原始作者的名字  *
// * 及版权信息。　　　　　　　　　　　　　　　　　　　　　　　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 框架开发：ＲａＲｎＵ　　　　　　　　　　　　　　　　　　　  *
// * 联系邮箱：ＶＩＶＡ＿ＫＩＬＬＥＲ＠１６３．ＣＯＭ　　　　　  *
// * 作者网站：ＨＴＴＰ：／／ＷＷＷ．ＢＵＧＵＡ．ＮＥＴ　　　　  *
// ****************************************************

package com.rarnu.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeSet;

import org.springframework.util.Assert;

import com.rarnu.consts.SystemConsts;

/**
 * 字符串工具类
 * 
 * @author RaRnU ORZ
 * 
 */
public abstract class StringUtils {

	public StringUtils() {
	}

	public static boolean hasLength(java.lang.String str) {
		return str != null && str.length() > 0;
	}

	public static boolean hasText(java.lang.String str) {
		int strLen;
		if (str == null || (strLen = str.length()) == 0)
			return false;
		for (int i = 0; i < strLen; i++)
			if (!Character.isWhitespace(str.charAt(i)))
				return true;

		return false;
	}

	public static String trimLeadingWhitespace(String str) {
		if (str.length() == 0)
			return str;
		StringBuffer buf;
		for (buf = new StringBuffer(str); buf.length() > 0
				&& Character.isWhitespace(buf.charAt(0)); buf.deleteCharAt(0))
			;
		return buf.toString();
	}

	public static String trimTrailingWhitespace(String str) {
		if (str.length() == 0)
			return str;
		StringBuffer buf;
		for (buf = new StringBuffer(str); buf.length() > 0
				&& Character.isWhitespace(buf.charAt(buf.length() - 1)); buf
				.deleteCharAt(buf.length() - 1))
			;
		return buf.toString();
	}

	public static boolean startsWithIgnoreCase(String str, String prefix) {
		if (str == null || prefix == null)
			return false;
		if (str.startsWith(prefix))
			return true;
		if (str.length() < prefix.length()) {
			return false;
		} else {
			String lcStr = str.substring(0, prefix.length()).toLowerCase();
			String lcPrefix = prefix.toLowerCase();
			return lcStr.equals(lcPrefix);
		}
	}

	public static boolean endsWithIgnoreCase(String str, String suffix) {
		if (str == null || suffix == null)
			return false;
		if (str.endsWith(suffix))
			return true;
		if (str.length() < suffix.length()) {
			return false;
		} else {
			String lcStr = str.substring(suffix.length()).toLowerCase();
			String lcSuffix = suffix.toLowerCase();
			return lcStr.equals(lcSuffix);
		}
	}

	public static int countOccurrencesOf(String str, String sub) {
		if (str == null || sub == null || str.length() == 0
				|| sub.length() == 0)
			return 0;
		int count = 0;
		int pos = 0;
		for (int idx = 0; (idx = str.indexOf(sub, pos)) != -1;) {
			count++;
			pos = idx + sub.length();
		}

		return count;
	}

	public static String replace(String inString, String oldPattern,
			String newPattern) {
		if (inString == null)
			return null;
		if (oldPattern == null || newPattern == null)
			return inString;
		StringBuffer sbuf = new StringBuffer();
		int pos = 0;
		int index = inString.indexOf(oldPattern);
		int patLen = oldPattern.length();
		for (; index >= 0; index = inString.indexOf(oldPattern, pos)) {
			sbuf.append(inString.substring(pos, index));
			sbuf.append(newPattern);
			pos = index + patLen;
		}

		sbuf.append(inString.substring(pos));
		return sbuf.toString();
	}

	public static String delete(String inString, String pattern) {
		return org.springframework.util.StringUtils.replace(inString, pattern,
				SystemConsts.MARK_NULL);
	}

	public static String deleteAny(String inString, String charsToDelete) {
		if (inString == null || charsToDelete == null)
			return inString;
		StringBuffer out = new StringBuffer();
		for (int i = 0; i < inString.length(); i++) {
			char c = inString.charAt(i);
			if (charsToDelete.indexOf(((int) (c))) == -1)
				out.append(c);
		}

		return out.toString();
	}

	public static String unqualify(String qualifiedName) {
		return org.springframework.util.StringUtils.unqualify(qualifiedName,
				SystemConsts.SQL_DOT);
	}

	public static String unqualify(String qualifiedName, char separator) {
		return qualifiedName.substring(qualifiedName
				.lastIndexOf((int) separator) + 1);
	}

	public static String getFilename(String path) {
		int separatorIndex = path.lastIndexOf(SystemConsts.SQL_SPLIT);
		return separatorIndex == -1 ? path : path.substring(separatorIndex + 1);
	}

	public static String applyRelativePath(String path, String relativePath) {
		int separatorIndex = path.lastIndexOf(SystemConsts.SQL_SPLIT);
		if (separatorIndex != -1) {
			String newPath = path.substring(0, separatorIndex);
			if (!relativePath.startsWith(SystemConsts.SQL_SPLIT))
				newPath = newPath + SystemConsts.SQL_SPLIT;
			return newPath + relativePath;
		} else {
			return relativePath;
		}
	}

	public static String cleanPath(String path) {
		String pathToUse = org.springframework.util.StringUtils.replace(path,
				SystemConsts.SQL_SPLIT_2, SystemConsts.SQL_SPLIT);
		int prefixIndex = pathToUse.indexOf(SystemConsts.SQL_COLON);
		String prefix = SystemConsts.MARK_NULL;
		if (prefixIndex != -1) {
			prefix = pathToUse.substring(0, prefixIndex + 1);
			pathToUse = pathToUse.substring(prefixIndex + 1);
		}
		String pathArray[] = org.springframework.util.StringUtils
				.delimitedListToStringArray(pathToUse, SystemConsts.SQL_SPLIT);
		List<String> pathElements = new LinkedList<String>();
		int tops = 0;
		for (int i = pathArray.length - 1; i >= 0; i--) {
			if (SystemConsts.SQL_DOT_1.equals(pathArray[i]))
				continue;
			if (SystemConsts.SQL_DOT_2.equals(pathArray[i])) {
				tops++;
				continue;
			}
			if (tops > 0)
				tops--;
			else
				pathElements.add(0, pathArray[i]);
		}

		return prefix
				+ org.springframework.util.StringUtils
						.collectionToDelimitedString(
								((Collection<String>) pathElements),
								SystemConsts.SQL_SPLIT);
	}

	public static boolean pathEquals(String path1, String path2) {
		return org.springframework.util.StringUtils.cleanPath(path1).equals(
				org.springframework.util.StringUtils.cleanPath(path2));
	}

	public static Locale parseLocaleString(String localeString) {
		String parts[] = org.springframework.util.StringUtils
				.tokenizeToStringArray(localeString,
						SystemConsts.SQL_UNDER_LINE, false, false);
		String language = parts.length <= 0 ? SystemConsts.MARK_NULL : parts[0];
		String country = parts.length <= 1 ? SystemConsts.MARK_NULL : parts[1];
		String variant = parts.length <= 2 ? SystemConsts.MARK_NULL : parts[2];
		return language.length() <= 0 ? null : new Locale(language, country,
				variant);
	}

	public static String[] addStringToArray(String arr[], String str) {
		String newArr[] = new String[arr.length + 1];
		System.arraycopy(arr, 0, newArr, 0, arr.length);
		newArr[arr.length] = str;
		return newArr;
	}

	public static String[] sortStringArray(String source[]) {
		if (source == null) {
			return new String[0];
		} else {
			Arrays.sort(source);
			return source;
		}
	}

	public static String[] split(String toSplit, String delimiter) {
		Assert.hasLength(toSplit, String.format(SystemConsts.EXCEPTION_INFO,
				"Cannot split a null or empty string"));
		Assert.hasLength(delimiter, String.format(SystemConsts.EXCEPTION_INFO,
				"Cannot use a null or empty delimiter to split a string"));
		int offset = toSplit.indexOf(delimiter);
		if (offset < 0) {
			return null;
		} else {
			String beforeDelimiter = toSplit.substring(0, offset);
			String afterDelimiter = toSplit.substring(offset
					+ delimiter.length());
			return (new String[] { beforeDelimiter, afterDelimiter });
		}
	}

	public static Properties splitArrayElementsIntoProperties(String array[],
			String delimiter) {
		return org.springframework.util.StringUtils
				.splitArrayElementsIntoProperties(array, delimiter, null);
	}

	public static Properties splitArrayElementsIntoProperties(String array[],
			String delimiter, String charsToDelete) {
		if (array == null || array.length == 0)
			return null;
		Properties result = new Properties();
		for (int i = 0; i < array.length; i++) {
			String element = array[i];
			if (charsToDelete != null)
				element = org.springframework.util.StringUtils.deleteAny(
						array[i], charsToDelete);
			String splittedElement[] = org.springframework.util.StringUtils
					.split(element, delimiter);
			if (splittedElement != null)
				result.setProperty(splittedElement[0].trim(),
						splittedElement[1].trim());
		}

		return result;
	}

	public static String[] tokenizeToStringArray(String str, String delimiters) {
		return org.springframework.util.StringUtils.tokenizeToStringArray(str,
				delimiters, true, true);
	}

	public static String[] tokenizeToStringArray(String str, String delimiters,
			boolean trimTokens, boolean ignoreEmptyTokens) {
		StringTokenizer st = new StringTokenizer(str, delimiters);
		List<String> tokens = new ArrayList<String>();
		do {
			if (!st.hasMoreTokens())
				break;
			String token = st.nextToken();
			if (trimTokens)
				token = token.trim();
			if (!ignoreEmptyTokens || token.length() > 0)
				tokens.add(token);
		} while (true);
		return (String[]) tokens.toArray(new String[tokens.size()]);
	}

	public static String[] delimitedListToStringArray(String str,
			String delimiter) {
		if (str == null)
			return new String[0];
		if (delimiter == null)
			return (new String[] { str });
		List<String> result = new ArrayList<String>();
		int pos = 0;
		for (int delPos = 0; (delPos = str.indexOf(delimiter, pos)) != -1;) {
			result.add(str.substring(pos, delPos));
			pos = delPos + delimiter.length();
		}

		if (str.length() > 0 && pos <= str.length())
			result.add(str.substring(pos));
		return (String[]) result.toArray((Object[]) new String[result.size()]);
	}

	public static String[] commaDelimitedListToStringArray(String str) {
		return org.springframework.util.StringUtils.delimitedListToStringArray(
				str, SystemConsts.SQL_COMMA);
	}

	public static Set<String> commaDelimitedListToSet(String str) {
		Set<String> set = new TreeSet<String>();
		String tokens[] = org.springframework.util.StringUtils
				.commaDelimitedListToStringArray(str);
		for (int i = 0; i < tokens.length; i++)
			set.add(tokens[i]);

		return set;
	}

	public static String arrayToDelimitedString(Object arr[], String delim) {
		if (arr == null)
			return SystemConsts.MARK_NULL;
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < arr.length; i++) {
			if (i > 0)
				sb.append(delim);
			sb.append(arr[i]);
		}

		return sb.toString();
	}

	public static String collectionToDelimitedString(Collection<String> coll,
			String delim, String prefix, String suffix) {
		if (coll == null)
			return SystemConsts.MARK_NULL;
		StringBuffer sb = new StringBuffer();
		Iterator<String> it = coll.iterator();
		for (int i = 0; it.hasNext(); i++) {
			if (i > 0)
				sb.append(delim);
			sb.append(prefix).append(it.next()).append(suffix);
		}

		return sb.toString();
	}

	public static String collectionToDelimitedString(Collection<String> coll,
			String delim) {
		return org.springframework.util.StringUtils
				.collectionToDelimitedString(coll, delim,
						SystemConsts.MARK_NULL, SystemConsts.MARK_NULL);
	}

	public static String arrayToCommaDelimitedString(Object arr[]) {
		return org.springframework.util.StringUtils.arrayToDelimitedString(arr,
				SystemConsts.SQL_COMMA);
	}

	public static String collectionToCommaDelimitedString(Collection<String> coll) {
		return org.springframework.util.StringUtils
				.collectionToDelimitedString(coll, SystemConsts.SQL_COMMA);
	}
}
