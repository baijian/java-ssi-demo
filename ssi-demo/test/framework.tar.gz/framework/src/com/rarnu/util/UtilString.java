// ****************************************************
// * Ｒａｒｎｕ　Ｆｒａｍｅｗｏｒｋ　　　　　　　　　　　　　　  *
// *　　　Ｆｏｒ　Ｊ２ＥＥ　Ｗｉｔｈ　ＡＪＡＸ　Ｖ１．０　　 　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 本框架是基于ＳＴＲＵＴＳ，ＳＰＲＩＮＧ，ＨＩＢＥＲＮＡＴＥ  *
// * 进行构建的，适用于企业级Ｊ２ＥＥ开发，内部封装了ＡＪＡＸ，  *
// * ＤＯＪＯ等常用框架，能够使开发变得轻松，效率非常高。开发人  *
// * 员只需要遵守本框架的开发规则，就能创建出层次清晰，代码高质  *
// * 量，运行效果良好的网站系统。　　　　　　　　　　　　　　　  *
// *                                                  *
// * 本框架遵从ＭＰＬ协议，您可以任意的传播，使用，或修改本框架  *
// * ，使它更符合您的开发流程，但是不得抹去本框架原始作者的名字  *
// * 及版权信息。　　　　　　　　　　　　　　　　　　　　　　　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 框架开发：ＲａＲｎＵ　　　　　　　　　　　　　　　　　　　  *
// * 联系邮箱：ＶＩＶＡ＿ＫＩＬＬＥＲ＠１６３．ＣＯＭ　　　　　  *
// * 作者网站：ＨＴＴＰ：／／ＷＷＷ．ＢＵＧＵＡ．ＮＥＴ　　　　  *
// ****************************************************

package com.rarnu.util;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import org.springframework.util.StringUtils;

import com.rarnu.consts.SystemConsts;

/**
 * 字符串工具类
 * 
 * @author RaRnU ORZ
 * 
 */
public class UtilString {

	public static List<?> splitList(String str) {
		return split(str, SystemConsts.SQL_COMMA);
	}

	public static List<?> splitList2(String strPara) {
		List<String> listResult = new ArrayList<String>();
		String[] strArr = strPara.split(SystemConsts.SQL_COMMA);
		for (int i = 0; i < strArr.length; i++) {
			String strWithYinhao = strArr[i];
			String strWithoutYinhao = removeYinhao(strWithYinhao);
			listResult.add(strWithoutYinhao);
		}
		return listResult;
	}

	public static String combList(List<?> strList) {

		StringBuffer sb = new StringBuffer();

		for (Iterator<?> iter = strList.iterator(); iter.hasNext();) {
			String str = (String) iter.next();
			sb.append(str + SystemConsts.SQL_COMMA);
		}
		if (sb.length() >= 1)
			sb.deleteCharAt(sb.length() - 1);

		return sb.toString();
	}

	public static String append(String str1, String str2, String str3) {
		if (str1 == null)
			str1 = SystemConsts.MARK_NULL;
		if (str2 == null)
			str2 = SystemConsts.MARK_NULL;
		if (str3 == null)
			str3 = SystemConsts.MARK_NULL;
		return str1 + str2 + str3;
	}

	public static String comb(List<?> strList) {
		if (strList.size() == 0)
			return SystemConsts.SQL_SINGLE_QUOTE_2;
		StringBuffer sb = new StringBuffer();

		for (Iterator<?> iter = strList.iterator(); iter.hasNext();) {
			String str = (String) iter.next();
			sb.append(SystemConsts.SQL_SINGLE_QUOTE + str
					+ SystemConsts.SQL_SINGLE_QUOTE + SystemConsts.SQL_COMMA);
		}
		if (sb.length() >= 1)
			sb.deleteCharAt(sb.length() - 1);

		return sb.toString();
	}

	public static String combNoComma(List<?> strList) {

		StringBuffer sb = new StringBuffer();

		for (Iterator<?> iter = strList.iterator(); iter.hasNext();) {
			String str = (String) iter.next();
			sb.append(str + SystemConsts.SQL_COMMA);
		}
		if (sb.length() >= 1)
			sb.deleteCharAt(sb.length() - 1);

		return sb.toString();
	}

	public static List<?> split(String str, String delim) {
		List<String> splitList = null;
		StringTokenizer st = null;

		if (str == null)
			return splitList;

		if (delim != null)
			st = new StringTokenizer(str, delim);
		else
			st = new StringTokenizer(str);

		if (st != null && st.hasMoreTokens()) {
			splitList = new ArrayList<String>();

			while (st.hasMoreTokens())
				splitList.add(st.nextToken());
		}
		return splitList;
	}

	public static String addComma(String str) {
		if (str == null)
			return null;
		List<?> lt = splitList(str);
		str = UtilString.comb(lt);
		return str;
	}

	public static List<?> splitByLine(String str) {
		return split(str, SystemConsts.SQL_SPLIT_3);
	}

	public static String getTwoSpitString(String str, boolean isBefore) {
		int len = str.length();
		int delpos = str.indexOf(SystemConsts.SQL_SPLIT_3);
		if (isBefore == true) {
			return str.substring(0, delpos);
		} else {
			return str.substring(delpos + 1, len);
		}
	}

	public static String getSplitString(String str, String denotation,
			boolean isBefore) {
		int len = str.length();
		int delpos = str.indexOf(denotation);
		if (delpos == -1)
			return SystemConsts.MARK_NULL;
		if (isBefore == true) {
			return str.substring(0, delpos);
		} else {
			return str.substring(delpos + 1, len);
		}
	}

	public static boolean notEmpty(String str) {
		if (str != null && !str.trim().equals(SystemConsts.MARK_NULL))
			return true;
		else
			return false;
	}

	public static String addCommaOrNot(String str) {
		if (str.indexOf(SystemConsts.SQL_COMMA) == -1)
			str = SystemConsts.SQL_SINGLE_QUOTE + str
					+ SystemConsts.SQL_SINGLE_QUOTE;
		else
			str = addComma(str);
		return str;
	}

	public static String getGBString(String str) {
		if (str == null)
			return null;
		try {
			str = new String(str.getBytes(SystemConsts.CHARSET_ISO));
		} catch (UnsupportedEncodingException e) {

		}
		return str;
	}

	public static String replaceToken(String str, String tk1, String tk2) {
		return StringUtils.replace(str, tk1, tk2);
	}

	public static String windowPathToNetPath(String str) {
		return replaceToken(str, SystemConsts.SQL_SPLIT_2,
				SystemConsts.SQL_SPLIT);
	}

	public static String toUtf8String(String s) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c >= 0 && c <= 255) {
				sb.append(c);
			} else {
				byte[] b;
				try {
					b = Character.toString(c).getBytes(
							SystemConsts.CHARSET_UTF_8);
				} catch (Exception ex) {
					System.out.println(ex);
					b = new byte[0];
				}
				for (int j = 0; j < b.length; j++) {
					int k = b[j];
					if (k < 0)
						k += 256;
					sb.append(SystemConsts.SQL_PERCENT
							+ Integer.toHexString(k).toUpperCase());
				}
			}
		}
		return sb.toString();
	}

	public static String removeYinhao(String str) {
		if (str == null)
			return str;
		int indexFirst = str.indexOf(SystemConsts.SQL_SINGLE_QUOTE);
		int indexLast = str.lastIndexOf(SystemConsts.SQL_SINGLE_QUOTE);
		if (indexFirst >= 0 && indexLast >= 0 && indexFirst <= indexLast) {
			return str.substring(indexFirst + 1, indexLast);
		}
		return null;
	}

	public static String stringTransfer(String strInit) {
		if (strInit == null)
			return strInit;
		strInit = strInit.trim();
		String[] strs = strInit.split(SystemConsts.SQL_COLON);
		String strResult = SystemConsts.MARK_NULL;
		for (int i = 0; i < strs.length; i++) {
			strResult += SystemConsts.SQL_SINGLE_QUOTE + strs[i]
					+ SystemConsts.SQL_SINGLE_QUOTE + SystemConsts.SQL_COMMA;
		}
		strResult = strResult.substring(0, strResult.length() - 1);
		return strResult;
	}

	public static int length(String str) throws Exception {
		int len = -1;
		try {
			len = new String(str.getBytes(), SystemConsts.CHASET_ISO_SOFT)
					.length();
		} catch (Exception e) {
			throw new Exception(String.format(SystemConsts.EXCEPTION_INFO,
					"error at method: UtilString1.length"));
		}
		return len;
	}

	public static int subString(String str, int begin, int end)
			throws Exception {
		int len = -1;
		try {
			len = new String(str.getBytes(), SystemConsts.CHASET_ISO_SOFT)
					.length();
		} catch (Exception e) {
			throw new Exception(String.format(SystemConsts.EXCEPTION_INFO,
					"error at method: UtilString1.length"));
		}
		return len;
	}
	
	public static String Utf8ToGbk(String utf8Str){
		byte [] b;
		String name = SystemConsts.MARK_NULL;
		try {
			b = utf8Str.getBytes(SystemConsts.CHASET_ISO_SOFT);
			name = new String(b, SystemConsts.CHARSET_GB2312);
		} catch (Exception e) {
		}
		return name;
	}
	
}