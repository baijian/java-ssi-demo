package com.rarnu.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * 输入输出工具类
 * 
 * @author RaRnU ORZ
 * 
 */
public class UtilIo {

	public static void CopyStream(InputStream from, OutputStream to) {
		byte[] buffer = new byte[8192];
		int got;
		try {
			while ((got = from.read(buffer, 0, buffer.length)) > 0)
				to.write(buffer, 0, got);
		} catch (IOException e) {

		}
	}

	public static boolean isExist(String file) {
		boolean b = false;
		File f = new File(file);
		if (f.exists())
			b = true;
		return b;
	}

}