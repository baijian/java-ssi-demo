// ****************************************************
// * Ｒａｒｎｕ　Ｆｒａｍｅｗｏｒｋ　　　　　　　　　　　　　　  *
// *　　　Ｆｏｒ　Ｊ２ＥＥ　Ｗｉｔｈ　ＡＪＡＸ　Ｖ１．０　　 　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 本框架是基于ＳＴＲＵＴＳ，ＳＰＲＩＮＧ，ＨＩＢＥＲＮＡＴＥ  *
// * 进行构建的，适用于企业级Ｊ２ＥＥ开发，内部封装了ＡＪＡＸ，  *
// * ＤＯＪＯ等常用框架，能够使开发变得轻松，效率非常高。开发人  *
// * 员只需要遵守本框架的开发规则，就能创建出层次清晰，代码高质  *
// * 量，运行效果良好的网站系统。　　　　　　　　　　　　　　　  *
// *                                                  *
// * 本框架遵从ＭＰＬ协议，您可以任意的传播，使用，或修改本框架  *
// * ，使它更符合您的开发流程，但是不得抹去本框架原始作者的名字  *
// * 及版权信息。　　　　　　　　　　　　　　　　　　　　　　　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 框架开发：ＲａＲｎＵ　　　　　　　　　　　　　　　　　　　  *
// * 联系邮箱：ＶＩＶＡ＿ＫＩＬＬＥＲ＠１６３．ＣＯＭ　　　　　  *
// * 作者网站：ＨＴＴＰ：／／ＷＷＷ．ＢＵＧＵＡ．ＮＥＴ　　　　  *
// ****************************************************

package com.rarnu.util;

import java.text.ParseException;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.orm.hibernate3.HibernateTemplate;

import com.rarnu.Pager;
import com.rarnu.consts.SystemConsts;
import com.rarnu.persistence.PagerHelper;

/**
 * 数居层工具类
 * 
 * @author RaRnU ORZ
 * 
 */
public class UtilDao {

	public static List<?> findForPage(Session session, Query query, Map<?,?> params)
			throws DataAccessResourceFailureException, HibernateException,
			IllegalStateException {
		setQueryParams(query, params);
		return query.list();

	}

	public static Map<?,?> findForPage(Session session, Query query, Map<?,?> params,
			Pager pager) throws DataAccessResourceFailureException,
			HibernateException, IllegalStateException {

		if (pager != null) {
			PagerHelper helper = new PagerHelper();
			pager.setTotal(helper.getQuerySize(session, query, params));
			query.setFirstResult(pager.getCurrentFirst());
			query.setMaxResults(pager.getPageSize());
		}

		setQueryParams(query, params);
		List<?> list = query.list();

		Map<String,Object> res = UtilBusiness.returnSuccess();
		UtilBusiness.returnValue(res, list);
		UtilBusiness.setPager(res, pager);

		return res;
	}

	public static void setQueryParams(Query query, Map<?,?> params)
			throws HibernateException {
		Set<?> entrySet = params.entrySet();
		for (Iterator<?> ite = entrySet.iterator(); ite.hasNext();) {
			Map.Entry<?,?> entry = (Map.Entry<?,?>) ite.next();
			query.setParameter((String) entry.getKey(), entry.getValue());

		}
	}

	public static boolean initActualDao(boolean isCache, HibernateTemplate ht,
			String qcr) {
		if (isCache == false) {
			ht.setCacheQueries(true);
			if (qcr != null) {
				ht.setQueryCacheRegion(qcr);
			}
			isCache = true;
		}
		return isCache;
	}

	public static void setSort(StringBuffer hsql, Map<?,?> map) {
		if (map.get(SystemConsts.ORDER_BY_SORT) != null)
			hsql.append(map.get(SystemConsts.ORDER_BY_SORT));
	}

	public static void setSort(StringBuffer hsql, Map<?, ?> map, String defaultSql) {
		if (map.get(SystemConsts.ORDER_BY_SORT) != null) {
			hsql.append(map.get(SystemConsts.ORDER_BY_SORT));
		} else {
			hsql.append(defaultSql);
		}
	}

	public static void setMapString(StringBuffer query,
			Map<String, String> queryMap, Map<?,?> argsMap, String strFieldName,
			String objPre, String operationStr) {
		String transId = (String) argsMap.get(strFieldName);
		if (objPre == null)
			objPre = SystemConsts.DEFAULT_OJB_NAME;
		if (UtilString.notEmpty(transId)) {
			query.append(SystemConsts.SQL_AND).append(objPre).append(
					SystemConsts.SQL_DOT_1).append(strFieldName).append(
					SystemConsts.SQL_SPACE).append(operationStr).append(
					SystemConsts.SQL_COLON_2).append(strFieldName);
			queryMap.put(strFieldName, transId);
		}
	}

	public static void setMapNotString(StringBuffer query,
			Map<String, Object> queryMap, Map<?,?> argsMap, String strFieldName,
			String objPre, String operationStr) {
		Object transId = argsMap.get(strFieldName);
		if (objPre == null)
			objPre = SystemConsts.DEFAULT_OJB_NAME;
		if (transId != null) {
			query.append(SystemConsts.SQL_AND).append(objPre).append(
					SystemConsts.SQL_DOT_1).append(strFieldName).append(
					SystemConsts.SQL_SPACE).append(operationStr).append(
					SystemConsts.SQL_COLON_2).append(strFieldName);
			queryMap.put(strFieldName, transId);
		}
	}

	public static void setMapString(StringBuffer query,
			Map<String, String> queryMap, String strArg, String strFieldName,
			String objPre, String operationStr) {
		if (objPre == null)
			objPre = SystemConsts.DEFAULT_OJB_NAME;
		if (UtilString.notEmpty(strArg)) {
			query.append(SystemConsts.SQL_AND).append(objPre).append(
					SystemConsts.SQL_DOT_1).append(strFieldName).append(
					SystemConsts.SQL_SPACE).append(operationStr).append(
					SystemConsts.SQL_COLON_2).append(strFieldName);
			queryMap.put(strFieldName, strArg);
		}
	}

	@SuppressWarnings("unchecked")
	public static void setSingleMapString(StringBuffer query, Map queryMap,
			Map argsMap, String strFieldName, String objPre) {

		UtilDao.setMapString(query, queryMap, argsMap, strFieldName, objPre,
				SystemConsts.SQL_EQUAL);
	}

	@SuppressWarnings("unchecked")
	public static void setEquals(StringBuffer query, Map queryMap, Map argsMap,
			String strFieldName, String objPre) {

		UtilDao.setMapNotString(query, queryMap, argsMap, strFieldName, objPre,
				SystemConsts.SQL_EQUAL);
	}

	@SuppressWarnings("unchecked")
	public static void setBlurMapString(StringBuffer query, Map queryMap,
			Map argsMap, String strFieldName, String objPre) {
		String strArg = null;
		if (UtilString.notEmpty((String) argsMap.get(strFieldName))) {
			strArg = SystemConsts.SQL_PERCENT
					+ (String) argsMap.get(strFieldName)
					+ SystemConsts.SQL_PERCENT;
		}
		UtilDao.setMapString(query, queryMap, strArg, strFieldName, objPre,
				SystemConsts.SQL_LIKE);
	}

	public static void setMulSingleMapString(StringBuffer query, Map<?,?> queryMap,
			Map<?,?> argsMap, String[] queryArr, String objPre) {
		for (int i = 0; i < queryArr.length; i++) {
			String str = queryArr[i];
			UtilDao.setSingleMapString(query, queryMap, argsMap, str, objPre);
		}

	}

	public static void setMulBlurMapString(StringBuffer query, Map<?,?> queryMap,
			Map<?,?> argsMap, String[] queryArr, String objPre) {
		for (int i = 0; i < queryArr.length; i++) {
			String str = queryArr[i];
			UtilDao.setBlurMapString(query, queryMap, argsMap, str, objPre);
		}

	}

	@SuppressWarnings("unchecked")
	public static void setTimeFromToMapString(StringBuffer query, Map queryMap,
			Map argsMap, String[] queryArr, String objPre)
			throws ParseException {
		if (queryArr.length != 3)
			return;
		else {
			if (objPre == null)
				objPre = SystemConsts.DEFAULT_OJB_NAME;
			String timeFromStr = queryArr[1];
			String transId1 = (String) argsMap.get(timeFromStr);
			if (UtilString.notEmpty(transId1)) {
				if (UtilString.notEmpty(objPre)) {
					query.append(SystemConsts.SQL_AND).append(objPre).append(
							SystemConsts.SQL_DOT_1).append(queryArr[0]).append(
							SystemConsts.SQL_GOET).append(
							SystemConsts.SQL_COLON).append(timeFromStr);
				} else {
					query.append(SystemConsts.SQL_AND).append(queryArr[0])
							.append(SystemConsts.SQL_GOET).append(
									SystemConsts.SQL_COLON).append(timeFromStr);
				}
				Date timeBegin = UtilsDate.getDate(transId1);
				queryMap.put(timeFromStr, timeBegin);
			}

			String timeToStr = queryArr[2];
			String transId2 = (String) argsMap.get(timeToStr);
			if (objPre == null)
				objPre = SystemConsts.DEFAULT_OJB_NAME;
			if (UtilString.notEmpty(transId2)) {
				if (UtilString.notEmpty(objPre)) {
					query.append(SystemConsts.SQL_AND).append(objPre).append(
							SystemConsts.SQL_DOT_1).append(queryArr[0]).append(
							SystemConsts.SQL_LT).append(SystemConsts.SQL_COLON)
							.append(timeToStr);
				} else {
					query.append(SystemConsts.SQL_AND).append(queryArr[0])
							.append(SystemConsts.SQL_LT).append(
									SystemConsts.SQL_COLON).append(timeToStr);
				}
				Date timeEnd = UtilsDate.getDate(transId2);
				timeEnd = UtilsDate.addDate(timeEnd, 1);
				queryMap.put(timeToStr, timeEnd);
			}
		}

	}

}