package com.rarnu.util;

import com.rarnu.consts.SystemConsts;

/**
 * HTML 工具类
 * @author RaRnU ORZ
 *
 */
public class UtilHtml {
	public static String strToHtml(String s) {
		if (s == null || s.equals(SystemConsts.MARK_NULL))
			return SystemConsts.MARK_NULL;
		s = s.replaceAll(SystemConsts.HTML_AND, SystemConsts.HTML_AND_FMT);
		s = s.replaceAll(SystemConsts.HTML_LT, SystemConsts.HTML_LT_FMT);
		s = s.replaceAll(SystemConsts.HTML_GT, SystemConsts.HTML_GT_FMT);
		s = s.replaceAll(SystemConsts.HTML_SPACE, SystemConsts.HTML_SPACE_FMT);
		s = s.replaceAll(SystemConsts.HTML_CRLF, SystemConsts.HTML_CRLF_FMT);
		s = s.replaceAll(SystemConsts.HTML_SINGLE_QUOTE, SystemConsts.HTML_SINGLE_QUOTE_FMT);
		return s;
	}
}