package com.rarnu.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.beanutils.PropertyUtils;

/**
 * 列表工具类
 * @author RaRnU ORZ
 *
 */
public class UtilList {

	public static List<?> toList(Object obj1) {
		ArrayList<Object> list = new ArrayList<Object>();
		list.add(obj1);
		return list;
	}

	public static List<?> toList(Object obj1, Object obj2) {
		ArrayList<Object> list = new ArrayList<Object>();
		list.add(obj1);
		list.add(obj2);
		return list;
	}

	public static List<?> toList(Object obj1, Object obj2, Object obj3) {
		ArrayList<Object> list = new ArrayList<Object>();
		list.add(obj1);
		list.add(obj2);
		list.add(obj3);
		return list;
	}

	public static List<?> toList(Object obj1, Object obj2, Object obj3, Object obj4) {
		ArrayList<Object> list = new ArrayList<Object>();
		list.add(obj1);
		list.add(obj2);
		list.add(obj3);
		list.add(obj4);
		return list;
	}

	public static List<?> toList(Object obj1, Object obj2, Object obj3,
			Object obj4, Object obj5) {
		ArrayList<Object> list = new ArrayList<Object>();
		list.add(obj1);
		list.add(obj2);
		list.add(obj3);
		list.add(obj4);
		list.add(obj5);
		return list;
	}

	public static List<?> propList(List<Object> beans, String prop) {
		List<Object> list = new ArrayList<Object>();
		for (Iterator<Object> iter = beans.iterator(); iter.hasNext();) {
			Object bean = (Object) iter.next();
			try {
				Object propobj = PropertyUtils.getProperty(bean, prop);
				list.add(propobj);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return list;
	}

}
