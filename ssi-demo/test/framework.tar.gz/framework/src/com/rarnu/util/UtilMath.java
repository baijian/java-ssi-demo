// ****************************************************
// * Ｒａｒｎｕ　Ｆｒａｍｅｗｏｒｋ　　　　　　　　　　　　　　  *
// *　　　Ｆｏｒ　Ｊ２ＥＥ　Ｗｉｔｈ　ＡＪＡＸ　Ｖ１．０　　 　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 本框架是基于ＳＴＲＵＴＳ，ＳＰＲＩＮＧ，ＨＩＢＥＲＮＡＴＥ  *
// * 进行构建的，适用于企业级Ｊ２ＥＥ开发，内部封装了ＡＪＡＸ，  *
// * ＤＯＪＯ等常用框架，能够使开发变得轻松，效率非常高。开发人  *
// * 员只需要遵守本框架的开发规则，就能创建出层次清晰，代码高质  *
// * 量，运行效果良好的网站系统。　　　　　　　　　　　　　　　  *
// *                                                  *
// * 本框架遵从ＭＰＬ协议，您可以任意的传播，使用，或修改本框架  *
// * ，使它更符合您的开发流程，但是不得抹去本框架原始作者的名字  *
// * 及版权信息。　　　　　　　　　　　　　　　　　　　　　　　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 框架开发：ＲａＲｎＵ　　　　　　　　　　　　　　　　　　　  *
// * 联系邮箱：ＶＩＶＡ＿ＫＩＬＬＥＲ＠１６３．ＣＯＭ　　　　　  *
// * 作者网站：ＨＴＴＰ：／／ＷＷＷ．ＢＵＧＵＡ．ＮＥＴ　　　　  *
// ****************************************************

package com.rarnu.util;

import java.math.BigDecimal;

import com.rarnu.consts.SystemConsts;

/**
 * 数学运算工具类
 * 
 * @author RaRnU ORZ
 * 
 */
public class UtilMath {

	public static Long add(Long arg1, Long arg2) {
		if (arg1 != null && arg2 != null) {
			return new Long(arg1.longValue() + arg2.longValue());
		} else if (arg1 == null) {
			if (arg2 != null) {
				return arg2;
			} else {
				return new Long(0);
			}
		} else {
			return arg1;
		}

	}

	public static Long add(Long arg1, Long arg2, Long arg3) {
		return add(add(arg1, arg2), arg3);
	}

	public static Integer subtractInteger(Integer arg1, Integer arg2) {
		if (arg1 != null && arg2 != null) {
			return new Integer(arg1.intValue() - arg2.intValue());
		} else
			return null;
	}

	public static Long subtract(Long arg1, Long arg2) {
		if (arg1 != null && arg2 != null) {
			return new Long(arg1.longValue() - arg2.longValue());
		} else if (arg1 == null) {
			if (arg2 != null) {
				return new Long(-arg2.longValue());
			} else {
				return new Long(0);
			}
		} else {
			return arg1;
		}
	}

	public static BigDecimal add(BigDecimal big1, BigDecimal big2) {
		if (big1 != null && big2 != null)
			return big1.add(big2);

		if (big1 == null)
			return big2;

		if (big2 == null)
			return big1;

		return new BigDecimal(0);
	}

	public static BigDecimal multiply(BigDecimal big1, BigDecimal big2) {
		if (big1 != null)
			return big1.multiply(big2);
		return new BigDecimal(0);
	}

	public static BigDecimal multiply(BigDecimal big1, Long long1) {
		if (long1 == null)
			return new BigDecimal(0);
		if (big1 != null)
			return big1.multiply(new BigDecimal(long1.longValue()));
		return new BigDecimal(0);
	}

	public static Long getLongValue(String str) {
		Long returnL = null;
		try {
			returnL = new Long(str.trim());
		} catch (Exception e) {
			returnL = new Long(0);
		}
		return returnL;
	}

	public static BigDecimal getNullReturnBigDecimal(BigDecimal bd) {
		return (bd == null ? new BigDecimal(0) : bd);
	}

	public static Long getNullReturnLong(Long l) {
		return (l == null ? new Long(0) : l);
	}

	public static double round(BigDecimal v, int scale) {
		if (scale < 0) {
			throw new IllegalArgumentException(String.format(
					SystemConsts.EXCEPTION_INFO,
					"The scale must be a positive integer or zero"));
		}
		BigDecimal one = new BigDecimal("1");
		return v.divide(one, scale, BigDecimal.ROUND_HALF_UP).doubleValue();
	}

	public static boolean BDEquals(BigDecimal bd1, BigDecimal bd2) {
		if (bd1 == null || bd2 == null) {
			return false;
		} else if (bd1.compareTo(bd2) == 0) {
			return true;
		} else {
			return false;
		}
	}
}