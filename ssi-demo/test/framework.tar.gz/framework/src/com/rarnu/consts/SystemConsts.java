// ****************************************************
// * Ｒａｒｎｕ　Ｆｒａｍｅｗｏｒｋ　　　　　　　　　　　　　　  *
// *　　　Ｆｏｒ　Ｊ２ＥＥ　Ｗｉｔｈ　ＡＪＡＸ　Ｖ１．０　　 　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 本框架是基于ＳＴＲＵＴＳ，ＳＰＲＩＮＧ，ＨＩＢＥＲＮＡＴＥ  *
// * 进行构建的，适用于企业级Ｊ２ＥＥ开发，内部封装了ＡＪＡＸ，  *
// * ＤＯＪＯ等常用框架，能够使开发变得轻松，效率非常高。开发人  *
// * 员只需要遵守本框架的开发规则，就能创建出层次清晰，代码高质  *
// * 量，运行效果良好的网站系统。　　　　　　　　　　　　　　　  *
// *                                                  *
// * 本框架遵从ＭＰＬ协议，您可以任意的传播，使用，或修改本框架  *
// * ，使它更符合您的开发流程，但是不得抹去本框架原始作者的名字  *
// * 及版权信息。　　　　　　　　　　　　　　　　　　　　　　　  *
// *　　　　　　　　　　　　　　　　　　　　　　　　　　　　　   *
// * 框架开发：ＲａＲｎＵ　　　　　　　　　　　　　　　　　　　  *
// * 联系邮箱：ＶＩＶＡ＿ＫＩＬＬＥＲ＠１６３．ＣＯＭ　　　　　  *
// * 作者网站：ＨＴＴＰ：／／ＷＷＷ．ＢＵＧＵＡ．ＮＥＴ　　　　  *
// ****************************************************

package com.rarnu.consts;

/**
 * 常量定义类
 * 
 * @author RaRnU ORZ
 * 
 */
public class SystemConsts {

	/**
	 * 发送短信格式字符串<br>
	 * 参数1: 接收方手机号<br>
	 * 参数2: Modem 端口号
	 */
	public static final String SMS_SEND_FORMAT = "sms://+%s:%s";

	/**
	 * 默认的 Modem 端口<br>
	 * 端口号：50000
	 */
	public static final String SMS_PORT_DEFAULT = "50000";

	/**
	 * 当前分页序号
	 */
	public static final String CURRENT_PAGE_NUM = "current_page_num";

	/**
	 * 点击标题排序
	 */
	public static final String ORDER_BY_SORT = "sort";

	public static final String ORDER_BY_DIR = "dir";

	public static final String ORDER_BY_TARGER = "targer";

	public static final String RESULT = "result";

	public static final String RESULT_SUCCESS = "success";

	public static final String RESULT_WARN = "warn";

	public static final String RESULT_ERROR = "error";

	public static final String MSG = "msg";

	public static final String MSG2 = "msg2";

	public static final String RETURN = "return";

	public static final String PAGER = "PAGER";

	public static final String VALUE = "value";

	public static final String DEFAULT_OJB_NAME = "model";

	public static final String MARK_UP = "▲";

	public static final String MARK_DOWN = "▼";

	public static final String MARK_NULL = "";

	public static final String JSP_SORT_FMT = "<span title='点击排序' style='cursor: hand;' onclick=\"processQuery('%s','%s')\">%s</span>%s";

	/**
	 * 每页行数定义
	 */
	public static final int PAGE_SIZE = 10;

	public static final int PAGE_SIZE_2 = 5;

	/**
	 * 命令执行结果
	 */
	public static final String COMMAND_EXECUTE_RESULT = "commond_execute_result";

	/**
	 * hibernate 配置
	 */
	public static final String HIBERNATE_CONTENT = "applicationContext-hibernate.xml";

	/**
	 * command-mapping 配置
	 */
	public static final String COMMAND_MAPPING = "/command-mapping.xml";

	public static final String MODE_EJB = "EJB";

	public static final String MODE_BEAN = "bean";

	public static final String MODE_SPRING = "spring";

	public static final String ELEMENT_ID = "id";

	public static final String ELEMENT_PROCESSOR = "processor";

	public static final String ELEMENT_FUNCTION = "function";

	public static final String ELEMENT_INIT_MODE = "init-mode";

	public static final String STRING_BUILDER_PROCESSOR = "processor ";

	public static final String STRING_BUILDER_COMMAND = "Command ";

	public static final String COMMAND_MAPPING_ELEMENT = "//command";

	public static final String COMMAND_HELPER = "commandHelper";

	/**
	 * 出错信息
	 */
	public static final String EXCEPTION_INFO = "Error! Information: %s";

	public static final String EXCEPTION_METHOD_NOT_FOUND = "Method [%s] not found!";

	/**
	 * 字符编码
	 */
	public static final String CHARSET_ISO = "ISO8859_1";
	
	public static final String CHASET_ISO_SOFT = "8859_1";

	public static final String CHARSET_UTF_8 = "utf-8";
	
	public static final String CHARSET_GB2312 = "gb2312";

	public static final String CHARSET_ENCODING = "encoding";

	public static final String CHARSET_IGNORE = "ignore";

	/**
	 * 通用常量
	 */
	public static final String STR_YES = "yes";

	public static final String STR_NO = "no";

	public static final String STR_TRUE = "true";

	public static final String STR_FALSE = "false";

	public static final String STR_CHANGED = "changed";

	public static final String STR_UNCHANGED = "inchanged";

	public static final String STR_ERRORS = "errors";

	public static final String STR_VALUE = "value";

	public static final String STR_SELECTED = " selected";
	
	public static final String STR_GET = "get";
	
	public static final String STR_NAME = "name";

	/**
	 * 数据操作 sql 语句常量
	 */
	public static final String SQL_FROM = "FROM";

	public static final String SQL_DISTINCT = "DISTINCT";

	public static final String SQL_COMMA = ",";
	
	public static final char SQL_DOT = '.';
	
	public static final String SQL_DOT_1 = ".";
	
	public static final String SQL_DOT_2 = "..";	
	
	public static final String SQL_UNDER_LINE = "_ ";
	
	public static final String SQL_COLON = ":";
	
	public static final String SQL_SINGLE_QUOTE = "'";
	
	public static final String SQL_SINGLE_QUOTE_2 = "''";
	
	public static final String SQL_COLON_2 = " :";
	
	public static final String SQL_SPLIT = "/";
	
	public static final String SQL_SPLIT_2 = "\\";
	
	public static final String SQL_SPLIT_3 = "|";
	
	public static final String SQL_PERCENT = "%";

	public static final String SQL_AND_CHAR = "&";

	public static final String SQL_EQUAL = "=";

	public static final String SQL_SELECT_ALL = "select count(*) ";

	public static final String SQL_SELECT_FIELD = "select count ( %s )";

	public static final String SQL_ORDER_UPPER = " ORDER ";

	public static final String SQL_ORDER_LOWER = " order ";

	public static final String SQL_GRUOP_UPPER = " GROUP ";

	public static final String SQL_GRUOP_LOWER = " group ";

	public static final String SQL_DESC = "desc";

	public static final String SQL_ASC = "asc";
	
	public static final String SQL_AND = " and ";
	
	public static final String SQL_SPACE = " ";
	
	public static final String SQL_LIKE = "like";
	
	public static final String SQL_GOET = " >= ";
	
	public static final String SQL_LT = " < ";

	/**
	 * 查询请求常量
	 */

	public static final String PRICE_1 = "price1";

	public static final String PRICE_2 = "price2";

	public static final String Q_FOR_WHAT = "forWhat";

	public static final String Q_FILL = "fill";

	public static final String Q_RETURN_QUERY = "isReturnQuery";

	/**
	 * 全局异常常量
	 */
	public static final String GLOBAL_ERROR_CLASS = "org.apache.struts.action.GLOBAL_ERROR";

	public static final String GLOBAL_ERROR_STR = "global.error";

	/**
	 * 日期选择常量
	 */
	public static final String DATE_FORMAT = "yyyy-mm-dd";
	
	public static final String MONTH_DAY = "M/d";
	
	public static final String DATE_TIME_FULL = "yyyy-MM-dd HH:mm:ss";
	
	public static final String DATE_TIME_NO_SECOND = "yyyy-MM-dd HH:mm";
	
	public static final String DATE_TIME_FULL_2 = "yyMMddHHmmss";
	
	public static final String DATE_PART = "yyMMdd";
	
	public static final String DATE_PART_2 = "yyyy-MM-dd";
	
	public static final String YEAR = "yyyy";
	
	public static final String MONTH = "MM";
	
	public static final String MONTH_2 = "M";
	
	public static final String DAY = "dd";
	
	public static final String DAY_2 = "d";
	
	public static final String HOUR = "H";
	
	public static final String MINUTE = "m";

	public static final String JSP_DATE_SELECT_FMT = "<input type=image src='../images/icon-appt.gif' onclick='popUpCalendar(this, $(\"%s\"), \"%s\");return false;' value='请选择' style='font-size:11px'>";

	public static final String JSP_DAY_FMT = "<option value=\'%s\'%s>%s</option>";

	public static final String JSP_TIME_SELECT_FMT = "<input type=image src='../common/gif/icon-appttime.gif' onclick='selectTime(this.form.elements[\"%s\"],\"请先选择日期！\");return false;' />";

	public static final String JSP_SHOW_DATE_FMT = "<input type=text name='%s' %s %s %s %s %s %s %s onClick=\"return showCalendar(this,'y-mm-dd');\" />";
	/**
	 * html 替换
	 */
	public static final String HTML_AND = "&";
	
	public static final String HTML_AND_FMT = "&amp;";
	
	public static final String HTML_LT = "<";
	
	public static final String HTML_LT_FMT = "&lt;";
	
	public static final String HTML_GT = ">";
	
	public static final String HTML_GT_FMT = "&gt;";
	
	public static final String HTML_SPACE = "  ";
	
	public static final String HTML_SPACE_FMT = "&nbsp;";
	
	public static final String HTML_CRLF = "\n";
	
	public static final String HTML_CRLF_FMT = "<br>";
	
	public static final String HTML_SINGLE_QUOTE = "'";
	
	public static final String HTML_SINGLE_QUOTE_FMT = "&#39";
	
	public final static String MODULE_RETURN = "MODULE_RETURN";
	
	/**
	 * 报表常量
	 */
	public final static String REPORT_ROOT_PATH = "/WEB-INF/reports";
	
	public final static String REPORT_CONFIG = "/WEB-INF/report-config.xml";
	
	public final static String REPORT_SURFIX = "./report";
	
	public final static String REPORT_NAME = "name";
	
	public final static String REPORT_DATA_SOURCE = "datasource";
	
	public static final String APPLET_CODEBASE = "/reports/appletCodebase";

    public static final String APPLET_CODEBASE_WITH_OUT_PRINT = "/reports/appletCodebaseWithoutPrint";
}
